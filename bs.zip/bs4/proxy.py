import requests

def get_proxy():
    return requests.get("http://119.3.163.177:5010/get/").content

def delete_proxy(proxy):
    requests.get("http://119.3.163.177:5010/delete/?proxy={}".format(proxy))

# your spider code

def getHtml():
    # ....
    retry_count = 5
    proxy = get_proxy()
    print (proxy)
    while retry_count > 0:
        try:
            html = requests.get('https://www.example.com', proxies={"http": "http://{}".format(proxy)})
            print(html.text)
            # 使用代理访问
            return html
        except Exception:
            retry_count -= 1
    # 出错5次, 删除代理池中代理
    delete_proxy(proxy)
    return None
while True:
    getHtml()
