import xlrd
import xlwt
from xpinyin import Pinyin
from datetime import date, datetime
import pandas as pd
from sqlalchemy import create_engine
db_conn='postgresql://' +'future_rw'+':'+'lA0cl5p8weik6ltO'+'@'+'119.3.212.60'+':'+'5432'+'/' +\
             'future'
engine=create_engine(db_conn)
def read_excel():
    workbook = xlrd.open_workbook(r'xlss/29.xls')
    sheet2 = workbook.sheet_by_name('月统计数据汇总')
    row = sheet2.nrows
    p = 0
    g=0
    z_h=[]
    z = []
    for i in range(row):

        rowdata = sheet2.row_values(i)
        # rowdata=[i for i in rowdata[:-1] if i !='']
        rowdata=rowdata[::-1]
        new_Data=[]
        for i in rowdata:
            if i =='':
                rowdata.remove(i)


            else:
                new_Data=rowdata[::-1]

                break
        # l.append(new_Data)
        # print(new_Data)
        if 8<=len(new_Data)>=9:
            # print(new_Data)
            z.append(new_Data)
            # print(z)
            # for i in z:
            #     print(i)


            # for i in z[0]:
            z_h.append(z[0])
    z_h[0][0]='code'
    z_h[0][3]='同比1'
    z_h[0][5]='环比'
    z_h[0][8]='同比2'
    # print(z_h[0])
    p=Pinyin()
    test=p.get_initials(str(z_h[0]),'')
    test=test.lower()
    for i in z[1:19]:
       i[0]=i[0][-2:]
    # print(z[1:19])


    df=pd.DataFrame(z[1:23],columns=['code', 'dy', 'qntq', 'tb1', 'sy', 'hb', 'dnlj', 'qntqlj', 'tb2'])
    # print(df)
    # df.columns(test)
    # a=df.columns.values.tolist()
    # # print(a)
    df.to_sql('odl_fu_dc_turnover_2017_month_1',engine, schema="odl", index=False, if_exists="append",chunksize = 1000)
    print(df)

    # df.to_excel('888.xls')




read_excel()
