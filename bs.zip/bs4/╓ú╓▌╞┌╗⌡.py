# 每日行情
from bs4 import BeautifulSoup
import requests
import json
import pandas as pd
import numpy as np
from code_normally import *
import xlrd
import data
import csv
from tushare.stock.fundamental import get_stock_basics
import time


# # today = time.strftime("%Y%m%d", time.localtime())
# # # print(today)
# # year = time.strftime('%Y', time.localtime())
#
# #
# # #
# # 每日行情
def daily_market(td):
#     '''
#     郑州期货每日行情
#     日期已做处理 填入字符串 YYYY-MM-DD
#     #
#     # -------
# #   DataFrme :品种月份
#             昨结算
#             今开盘
#             最高价
#             最低价
#             今收盘
#             今结算
#             涨跌1
#             涨跌2
#             成交量（手）
#             空盘量
#             增减量
#             成交额(万元)
#             交割结算价
#     :param td:
#     :return:
#     '''
    td = zheng_day(td)
    try:

        r = requests.get(DAILY_MARKET % (td), heards)
        r.encoding = 'utf-8'
        # print(r.text)
        # soup = BeautifulSoup(r.text, 'lxml')

        a = pd.read_html(r.text, parse_dates=True, header=0)
        return a


    except:
        return None


#
#
a=daily_market('20190517')
# # print(a)
#
#
#
# # 结算参数/
def settlement_parameter(td):
#     '''
#       郑州期货结算参数
#     日期已做处理 填入字符串 YYYYMMDD
#     #
#     # -------
# #   DataFrme
#             合约代码
#             当日结算价
#             是否单边市
#             连续单边市天数
#             买交易保证金率（%)
#             卖交易保证金率（%）
#             交易手续费
#             交割手续费
#             平今仓手续费
#
#     :param td:
#     :return:
#     '''
    td=zheng_day(td)
    try:

        r = requests.get(SETTLEMENT_PARAMETERS%(td), heards)
        r.encoding = 'utf-8'
        # print(r.text)
        a = pd.read_html(r.text, parse_dates=True, header=0)
        return a
    except:
        return None

# #
# #
# # # #
#
# # 成交排名
def deal_the_ranking(td):
#     '''郑州期权成交排名
#         日期已做处理 填入字符串 YYYYMMDD
#
# #   DataFrme
#             名次
#             会员号
#             会员简称
#             成交量（手）
#
#
#     :param td:
#     :return:
#     '''
    td=zheng_day(td)
    try:


        r = requests.get(TRANSACTION_RANKING%(td),heards)
        r.encoding = 'utf-8'
        # print(r.text)
        a = pd.read_html(r.text, parse_dates=True, header=0)
        return a
    except:
        return None


deal_the_ranking('20190617')

#
# # 持仓排名
def position_ranking(td):
#     '''
#     郑州期权持仓排名
#         日期已做处理 填入字符串 YYYYMMDD
#
# #   DataFrme
#             名次
#             会员简称
#             成交量（手）
#             增减量
#             持买仓量
#     :param td:
#     :return:
#     '''
    td=zheng_day(td)
    try:


        r = requests.get(POSTION_RANKING%(td),heards)
        r.encoding = 'utf-8'
        # print(r.text)
        a = pd.read_html(r.text, parse_dates=True, header=0)

        return a
    except:
        return None


position_ranking('20190617')

#
# # 套保持仓
def hedge_position(td):
#     '''
#     郑州期权套保持仓
#         日期已做处理 填入字符串 YYYYMMDD
#
# #   DataFrme
#             品种
#             买套保额度
#             期货买套保持仓量
#             卖套保额度
#             期货卖套保持仓量
#     :param td:
#     :return:
#     '''
    td=zheng_day(td)
    try:
        from bs4 import BeautifulSoup
        import requests
        import pandas as pd
        import csv

        r = requests.get(HEDGE_POSITIO%(td),heards)
        r.encoding = 'utf-8'
        # print(r.text)
        a = pd.read_html(r.text, parse_dates=True, header=0)
        return a
    except:
        return None


hedge_position('20190617')
#
#
# # 仓单日报
def house_daily(td):
#     '''
#      郑州期权仓单日报
#         日期已做处理 填入字符串 YYYYMMDD
#
# #   DataFrme
#             仓库编号
#             仓库简称
#             年度
#             等级
#             品牌
#             仓单数量
#             当日增减
#             有效预报
#             升贴水
#     :param td:
#     :return:
#     '''
    td=zheng_day(td)
    try:
        from bs4 import BeautifulSoup
        import requests
        import pandas as pd
        import csv

        r = requests.get(WAREHOUSE_DAILY%(td),heards)
        r.encoding = 'utf-8'
        a = pd.read_html(r.text, parse_dates=True, header=0)

        return a
    except:
        return None

# # 期货阶段成交排名表1
def futures_stage_transactions(go,to):
    try:
        go=zheng_go(go)
        to=zheng_to(to)
        r=requests.post(FUTURES_STAGE_TRANSACTIONS,data={
            'querytype': 'tradeamt',
            'beginDate': go,
            'endDate': to,
            'classid': 'all',
        })
        # soup=BeautifulSoup(r.text,'lxml')
        # a=soup.xpath('//*[@id="toexcel"]/table/tbody')
        # print(a)
        a = pd.read_html(r.text, parse_dates=True, header=0)
        return a[3:]
    except:
        return None
#
#
#

# # print(b)
# # 期权阶段成交排名表2
def option_phase_trading_table(go,to):
    try:
        go=zheng_go(go)
        to=zheng_to(to)
        r=requests.post(FUTURES_STAGE_TRANSACTIONS,data={
            'querytype': 'tradeamt',
            'beginDate': go,
            'endDate': to,
            'classid': 'all',
        })
        # soup=BeautifulSoup(r.text,'lxml')
        # a=soup.xpath('//*[@id="toexcel"]/table/tbody')
        # print(a)
        a = pd.read_html(r.text, parse_dates=True, header=0)
        return a[3:]
    except:
        return None




# 期转现统计

def forward_transfer_statistics():
    try:


        r = requests.get(FORWARD_TRANSFER_STATISTICS,heards)
        r.encoding = 'utf-8'
        # print(r.text)
        a = pd.read_html(r.text, parse_dates=True, header=0)
        return a
    except:
        return None

forward_transfer_statistics()
# 月度交易总汇
import re
import time


# def monthly_trade_summary():
#     z = 0
#
#     # for i in range(1,6):
#     heards = {
#         'Accept': 'text / html, application / xhtml + xml, application / xml;q = 0.9, image / webp, image / apng, * / *;q = 0.8, application / signed - exchange;v = b3',
#         'Accept - Encoding': 'gzip, deflateAccept - Language: zh - CN, zh;q = 0.9, en;q = 0.8',
#         'Cache - Control': 'max - age = 0',
#         'Cookie': 'UM_distinctid=16b6934d2da52a-0580f28a0f55ac-e323069-144000-16b6934d2db660; TS014ada8c=0169c5aa321c389b96eb5bfb2fa43b9f9d4fd4c6ccae4f8dd2896fcf6c3748ee99e332b51b; CNZZDATA1264458526=1965444749-1560832974-null%7C1562220643',
#         'Host': 'www.czce.com.cn',
#         'f - Modified - Since': 'Wed, 03 Jul 2019 16:02: 51GMT',
#         'If - None - Match': 'W / "1421f-58cc8fe4780c0"',
#         'Proxy - Connection': 'keep - alive',
#         'Referer': 'http: // www.czce.com.cn / cn / jysj / ydjyhz / H770315index_2.htm',
#         'Upgrade - Insecure - Requests': 1,
#         'User - Agent': 'Mozilla / 5.0(Windows NT 10.0;Win64;x64) AppleWebKit / 537.36(KHTML, likeGecko) Chrome / 73.0.3683.103 Safari / 537.36',
#
#
#
#     }
#
#     urls = 'http://www.czce.com.cn/cn/jysj/ydjyhz/H770315index_1.htm'
#     # print(urls)
#     # for url in urls:
#     r = requests.get(urls, heards)
#     print(r)
#     soup = BeautifulSoup(r.text, 'lxml')
#     # a=soup.select('body > div.container > div:nth-child(2) > div.col-lg-9.col-md-9.col-xs-12 > div > div.pub_list1 > ul > table > tbody > tr:nth-child(1) > td > li:nth-child(5) > a')[0]
#     # print(a['href'])
#     b = z + 1
#     a = soup.select(' table > tbody > tr:nth-child(1) > td > li:nth-child(5) > a')[0]
#     # a = soup.select('tbody > tr:nth-child(1) > td:nth-child(1) li a ')
#     # print(a)
#     # for u in a:
#     xls = 'http://www.czce.com.cn' + a['href']
#     print(xls)
#     r = requests.get(xls, heards)
#     # for i in xls:
#     with open('1.xls', 'wb') as f:
#         f.write(r.content)
#
#         # data=xlrd.open_workbook(xls)
#         # print(data)
#         # if not pd:
#         # print(xls)
#         # f.close()
#
#         #
#         # try:
#     #
#     data = pd.read_excel(xls, sheet_name=None)
#     # dat = pd.read_excel('2.xls')
#     print(data)
#     # # data.to_excel(f"F:%s.xlsx" % (b), index=False)
#     # print(data)
#     # time.sleep(5)
#     # b = z + 1
#     # print(b)
#     # except:
#     #     print(None)
#
#
# monthly_trade_summary()
# 月度交割查询
def monthly_settlement_inquiry(td):
    try:


        r = requests.get(MONTHLY_SETTLEMENT_INQUIRY%(td),heards)
        r.encoding = 'utf-8'
        # print(r.text)
        a = pd.read_html(r.text, parse_dates=True, header=0)
        return a
    except:
        return None

# bb=monthly_settlement_inquiry('20190704')
#
# 月度行权查询
def monthly_exercise_query(td):
    try:


        r = requests.get(MONTHLY_EXERCISE_QUERY%(td),heards)
        r.encoding = 'utf-8'
        # print(r.text)
        a = pd.read_html(r.text, parse_dates=True, header=0)
        return a
    except:
        return None

# monthly_exercise_query('20190704')
# 月度市场报告\阅读市场报告
# def monthly_market_report_PDF():
#     import requests
#     from bs4 import BeautifulSoup
#     import pandas as pd
#     heards = {
#         'Accept': 'text / html, application / xhtml + xml, application / xml;q = 0.9, image / webp, image / apng, * / *;q = 0.8, application / signed - exchange;v = b3',
#         'Accept - Encoding': 'gzip, deflateAccept - Language: zh - CN, zh;q = 0.9, en;q = 0.8',
#         'Cache - Control': 'max - age = 0',
#         'Cookie': 'UM_distinctid=16b6934d2da52a-0580f28a0f55ac-e323069-144000-16b6934d2db660; TS014ada8c=0169c5aa321c389b96eb5bfb2fa43b9f9d4fd4c6ccae4f8dd2896fcf6c3748ee99e332b51b; CNZZDATA1264458526=1965444749-1560832974-null%7C1562220643',
#         'Host': 'www.czce.com.cn',
#         'f - Modified - Since': 'Wed, 03 Jul 2019 16:02: 51GMT',
#         'If - None - Match': 'W / "1421f-58cc8fe4780c0"',
#         'Proxy - Connection': 'keep - alive',
#         'Referer': 'http: // www.czce.com.cn / cn / jysj / ydjyhz / H770315index_2.htm',
#         'Upgrade - Insecure - Requests': 1,
#         'User - Agent': 'Mozilla / 5.0(Windows NT 10.0;Win64;x64) AppleWebKit / 537.36(KHTML, likeGecko) Chrome / 73.0.3683.103 Safari / 537.36',
#
#     }
#     pp = 0
#     for i in range(1,8):
#         url='http://www.czce.com.cn/cn/jysj/ydscbg/H770318index_%s.htm'%(i)
#
#         r=requests.get(url,heards)
#
#         # print(r)
#         soup=BeautifulSoup(r.text,'lxml')
#         a=soup.select(' table > tbody > tr:nth-child(1) > td > li > a')
#         # print(a)
#         for n in a:
#             print(n.text)
#             dd='http://www.czce.com.cn' +n['href']
#             pp+=1
#             r=requests.get(dd)
#             print(r.content)
#             with open ('月度市场报告\阅读市场报告%s.pdf'%(pp),'wb') as f:
#                 # f.write(n.text)
#                f.write(r.content)
#                print(r.content)
#
#
# monthly_market_report_PDF()
# import zipfile
# def the_historical_market():
#     url='http://www.czce.com.cn/cn/DFSStaticFiles/Future/2019/FutureDataHistory.zip'
#     r=requests.get(url)
#
#
#     with zipfile.ZipFile(r.content, 'r') as z:
#         f = z.open('KaggleCredit2.csv')
#         data = pd.read_csv(f, index_col=0)
# the_historical_market()
# #
#
# 月度行权查询
#
#
# print(aa)
#
# house_daily('20190617')
# 表1白糖期货合约
# 表2白糖期权合约( 白糖期货1909合约前执行本合约)
# 表3白糖期权合约( 白糖期货1909合约前执行本合约)
# 郑州期权合约
def sugar_futures_contract():

    l = []
    # df={}
    for url in map:
        r = requests.get(url, heards)
        r.encoding = 'utf-8'
        df = pd.read_html(r.text, parse_dates=True, header=0)
        df = df[0]
        x = np.array(df).tolist()
        # print (x)
        # print(x)
        bb = {}
        # b1={}
        # l=[]
        for i in x:
            # print (x[0],x[1])
            # print (x[0][i],x[1][i])
            bb[i[0]] = i[1]
        # print(bb)
        df = pd.DataFrame(bb, index=[0])
        # df=pd.DataFrame(b,index=[0])
        l.append(df)

    # print (l)
    #
    #
    dfd= pd.concat(l)
    dfd.to_excel('2122.xlsx')
    return pd.concat(l,sort=True)

# bu=sugar_futures_contract()
# print(bu)

