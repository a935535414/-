import time, datetime
from fake_useragent import UserAgent
from urllib.request import urlopen

ua = UserAgent()
heards = ua.chrome


# 变量必须是字符串
# 上海期货url日期格式
# tesw = '20190617'
def day1(td):
    timeArray = time.strptime(td, '%Y%m%d')
    return time.strftime('%Y%m%d', timeArray)


def month(sj):
    month_tews = sj[:-2]

    timeArray = time.strptime(month_tews, '%Y%m')
    return timeArray


# day1()
# print(ontherstyletime)

# 上海期货时间格式
# SHANGHAI_FUTURES_TIME_FORMAT = ontherstyletime
# 每日行情url
WEEK_MARKET_DATA = 'o_cursor'
SHANGHAI_FUTURES_url = 'http://www.shfe.com.cn/data/dailydata/option/%s.dat'
# Trade parameter url
# 交易参数url
RRADE_PARAMETER_URL_DATA = 'ContractDailyTradeArgument'
RRADE_PARAMETER_URL = 'http://www.shfe.com.cn/data/instrument/ContractDailyTradeArgument%s.dat'
# 上海期货交易所会员成交及持仓排名表
MEMBER_TRANSACTIONS_AND_POSITIONS = f'http://www.shfe.com.cn/data/dailydata/kx/pm%s.dat'
# 上海期货交易所货合约行情
CONTRACT_QUOTATION = f'http://www.shfe.com.cn/data/dailydata/kx/kx%s.dat'
# 上海期货交易所指定交割仓库期货仓单报告

DESIGNATED_DELIVERY_WAREHOUSE = f'http://www.shfe.com.cn/data/dailydata/%sdailystock.dat'
# 上海期货交易所指定交割仓库库存周报/
WAREHOUSE_INVENTORY_WEEKLY = f'http://www.shfe.com.cn/data/dailydata/%sweeklystock.dat'
# 当前合约加权平均价
WEIGHTED_AVERAGE_PRICE = f'http://www.shfe.com.cn/data/dailydata/ck/%sdefaultTimePrice.dat'
# 各品种合约加权平均价
AVERAGE_PRICE_OF_EACH_VARIETY_ONE = f'http://www.shfe.com.cn/data/dailydata/ck/%smainTimePrice.dat'
# 各品种合约加权平均价2
AVERAGE_PRICE_OF_EACH_VARIETY_WTO = f'http://www.shfe.com.cn/data/dailydata/ck/%sdailyTimePrice.dat'
# 上海期货交易所每周行情
WEEK_MARKET = f'http://www.shfe.com.cn/data/dailydata/%s.dat'
# 上海期货交易所上市品种月度参考价

MONTHLY_REFERENCE_PRICE = f'http://www.shfe.com.cn/data/dailydata/%sprice.dat'

# 上海期货交易所每月行情Monthly updates

MONTHLY_UPDATES = f'http://www.shfe.com.cn/data/dailydata/%smonth.dat'
# contract parameters
# 合约参数一览 期货
CONTRACT_PARAMETERS = f'http://www.shfe.com.cn/data/instrument/ContractBaseInfo%s.dat'
# 合约参数一览 衍生品futures_derivatives
FUTURES_DERIVATIVES = f'http://www.shfe.com.cn/data/instrument/option/ContractBaseInfo%s.dat'
# 合约参数一览 每日行情parameters_daily
PARAMETERS_DAILY = f'http://www.shfe.com.cn/data/dailydata/kx/kx%s.dat'
# 合约参数一览 每日行情 衍生品
QUOTE_DERIVATIVES = f'http://www.shfe.com.cn/data/dailydata/option/kx/kx%s.dat'
# 合约参数一览 每周行情 衍生品
WEEKLY_QUOTES = f'http://www.shfe.com.cn/data/dailydata/option/%s.dat'
# 每月行情衍生品
MONTHLY_QUOES = f'http://www.shfe.com.cn/data/dailydata/option/%smonth.dat'

# shang_mapp={'cu':'http://www.shfe.com.cn/products/cu/standard/90.html','al':'http://www.shfe.com.cn/products/al/standard/156.html',
#             'zn':'http://www.shfe.com.cn/products/zn/standard/159.html','pb':'http://www.shfe.com.cn/products/pb/standard/167.html',
#             'ni':'http://www.shfe.com.cn/products/ni/standard/911322404.html','sn':'http://www.shfe.com.cn/products/sn/standard/911322411.html',
#             'au':'http://www.shfe.com.cn/products/au/standard/173.html','ag':'http://www.shfe.com.cn/products/ag/standard/184.html',
#             'rb':'http://www.shfe.com.cn/products/rb/standard/194.html','wr':'http://www.shfe.com.cn/products/wr/standard/217.html',
#             'hc':'http://www.shfe.com.cn/products/hc/standard/911319779.html','fu':'http://www.shfe.com.cn/products/fu/standard/225.html',
#             'bu':'http://www.shfe.com.cn/products/bu/standard/233.html','ru':'http://www.shfe.com.cn/products/ru/standard/240.html',
#             'sp':'http://www.shfe.com.cn/products/sp/standard/text/','ruQ':'http://www.shfe.com.cn/products/ruQ/standard/911332992.html',
#             'cuQ':'http://www.shfe.com.cn/products/ruQ/standard/911332992.html'}
shang_mapp = ['http://www.shfe.com.cn/products/cu/standard/90.html',
              'http://www.shfe.com.cn/products/al/standard/156.html',
              'http://www.shfe.com.cn/products/zn/standard/159.html',
              'http://www.shfe.com.cn/products/pb/standard/167.html',
              'http://www.shfe.com.cn/products/ni/standard/911322404.html',
              'http://www.shfe.com.cn/products/sn/standard/911322411.html',
              'http://www.shfe.com.cn/products/au/standard/173.html',
              'http://www.shfe.com.cn/products/ag/standard/184.html',
              'http://www.shfe.com.cn/products/rb/standard/194.html',
              'http://www.shfe.com.cn/products/wr/standard/217.html',
              'http://www.shfe.com.cn/products/hc/standard/911319779.html',
              'http://www.shfe.com.cn/products/fu/standard/225.html',

              'http://www.shfe.com.cn/products/sp/standard/text/',
              # 'http://www.shfe.com.cn/products/ruQ/standard/911332992.html',
              # 'http://www.shfe.com.cn/products/cuQ/standard/911331454.html',
              ]
# 衍生品
MAPSS = ['http://www.shfe.com.cn/products/cuQ/standard/911331454.html',
         'http://www.shfe.com.cn/products/ruQ/standard/911332992.html'
         ]

tian_data = {'交易品种': '天然橡胶', '交易单位': '10吨/手', '报价单位': '元（人民币）/吨'
    , '最小变动价位': '5元/吨', '涨跌停板幅度': '上一交易日结算价+-3%', '合约月份': '1、3、4、5、6、7、8、9、10、11月'
    , '交易时间': '上午9:00 - 11:30，下午1:30 -3:00 和交易所规顶的其他交易时间',
             '最后交易日': '合约月份的15日（遇国家法定节假日顺延，春节月份等最后交易日交易所可另行调整并通知',
             '交割日期': '最后交易日后连续五个工作日',
             '交割品级': '标准品：1、国产天然橡胶（SCR WF），质量符合国际 GB/T8081-2008.2、进口3号烟胶片（RSS3）,质量符合《天然橡胶登记的品质与包装国际标准（绿皮书）》（1979年版。',
             '交割地点': '交易所指定交割仓库', '最低交易保证金': '合约价值的5%', '交割方式': '实物交割', '交割单位': '10吨', '交易代码': 'RU',
             '上市交易所': '上海期货交易所', }
shi_data = {'交易品种': '石油沥青', '交易单位': '10吨/手', '报价单位': '元（人民币）/吨'
    , '最小变动价位': '2元/吨', '涨跌停板幅度': '上一交易日结算价+-3%', '合约月份': '24个月以内，其中最近1-6个月为连续月份合约，6个月以后为季月合约'
    , '交易时间': '上午9:00 - 11:30，下午1:30 -3:00 和交易所规顶的其他交易时间',
            '最后交易日': '合约月份的15日（遇国家法定节假日顺延，春节月份等最后交易日交易所可另行调整并通知',
            '交割日期': '最后交易日后连续五个工作日',
            '交割品级': '70号A级道路石油沥青，具体内容见《上海期货交易所石油沥青期货交割实施细则（试行）》',
            '交割地点': '交易所指定交割仓库', '最低交易保证金': '合约价值的4%', '交割方式': '实物交割', '交割单位': '10吨', '交易代码': 'BU',
            '上市交易所': '上海期货交易所', }


# 上海期货交易所阴极铜期货合约
# cu='http://www.shfe.com.cn/products/cu/standard/90.html'
# # 交易所铝期货合约
# al='http://www.shfe.com.cn/products/al/standard/156.html'
# # 锌期货合约
# zn='http://www.shfe.com.cn/products/zn/standard/159.html'
# #铅期期货
# pb='http://www.shfe.com.cn/products/pb/standard/167.html'
# # 镍期货合约
# ni='http://www.shfe.com.cn/products/ni/standard/911322404.html'
# # 锡期货合约
# sn='http://www.shfe.com.cn/products/sn/standard/911322411.html'
# # 黄金期货合约
# au='http://www.shfe.com.cn/products/au/standard/173.html'
# #白银期货合约
# ag='http://www.shfe.com.cn/products/ag/standard/184.html'
# #螺纹钢期货合约
# rb='http://www.shfe.com.cn/products/rb/standard/194.html'
# #线材期货合约
# wr='http://www.shfe.com.cn/products/wr/standard/217.html'
# # 热轧卷板期货合约
# hc='http://www.shfe.com.cn/products/hc/standard/911319779.html'
# # 燃料油期货合约
# fu='http://www.shfe.com.cn/products/fu/standard/225.html'
# # 石油沥青期货合约
# bu='http://www.shfe.com.cn/products/bu/standard/233.html'
# # 天然橡胶期货合约
# ru='http://www.shfe.com.cn/products/ru/standard/240.html'
# # 漂白硫酸盐针叶木浆期货合约
# sp='http://www.shfe.com.cn/products/sp/standard/text/'
# # 天然橡胶期货期权合约
# ruQ='http://www.shfe.com.cn/products/ruQ/standard/911332992.html'
# # 阴极铜期货期权合约
# cuQ='http://www.shfe.com.cn/products/ruQ/standard/911332992.html'

# ------------------------------------------------------------------------------------------
# 郑州期货日期格式Zhengzhou futures date format
# tesw = '20190618'
# def zheng_day1(td):
#     timeArray = time.strptime(td, '%Y%m%d')
#     return time.strftime('%Y%m%d', timeArray)
def zheng_day(td):
    timeArray = time.strptime(td, '%Y%m%d')
    return time.strftime('%Y%m%d', timeArray)


def zheng_go(td):
    timeArray = time.strptime(td, '%Y%m%d')
    return time.strftime('%Y-%m-%d', timeArray)


def zheng_to(td):
    timeArray = time.strptime(td, '%Y%m%d')
    return time.strftime('%Y-%m-%d', timeArray)


# print(ontherstyletime)
# ZHENGZHOU_FUTURES_DATE = ontherstyletime

# 郑州每日行情daily market
DAILY_MARKET = f'http://www.czce.com.cn/cn/DFSStaticFiles/Future/2019/%s/FutureDataDaily.htm'
# 郑州结算参数settlement parameters
SETTLEMENT_PARAMETERS = f'http://www.czce.com.cn/cn/DFSStaticFiles/Future/2019/%s/FutureDataClearParams.htm'
# 郑州期货交易月历calendar of futures trading
# OF_FUTURES_TRADING = f'http://app.czce.com.cn/cms/pub/search/searchjyyl.jsp?tradetype=future'
#
# # 期权交易月历2
# OF_FUTURES_TRADING_TOW = f'http://app.czce.com.cn/cms/pub/search/searchjyyl.jsp?tradetype=option'

# 郑州成交排名transaction ranking
TRANSACTION_RANKING = f'http://www.czce.com.cn/cn/DFSStaticFiles/Future/2019/%s/FutureDataTradeamt.htm'
# 持仓排名Position ranking
POSTION_RANKING = f'http://www.czce.com.cn/cn/DFSStaticFiles/Future2019/%s/FutureDataHolding.htm'

# 套保持仓Hedge position
HEDGE_POSITIO = f'http://www.czce.com.cn/cn/DFSStaticFiles/Future/2019/%s/FutureDataTrdhedge.htm'

# 仓单日报Warehouse daily
WAREHOUSE_DAILY = f'http://www.czce.com.cn/cn/DFSStaticFiles/Future/2019/%s/FutureDataWhsheet.htm'

# 期货阶段成交排名表
FUTURES_STAGE_TRANSACTIONS = 'http://app.czce.com.cn/cms/QueryTradeHolding'
# Option phase trading table
OPTION_PHASE_TRADING_TABLE = 'http://app.czce.com.cn/cms/cmsface/czce/exchangeoptionfront/newdatatradeamt.jsp'
# 期转现统计
FORWARD_TRANSFER_STATISTICS = 'http://www.czce.com.cn/cn/DFSStaticFiles/Future/2019/20190703/FutureDataTrdtrades.htm'
# 月度交割查询
MONTHLY_SETTLEMENT_INQUIRY = 'http://www.czce.com.cn/cn/DFSStaticFiles/Future/2019/%s/FutureDataSettlematched.htm'
# 月度行权查询
MONTHLY_EXERCISE_QUERY = 'http://www.czce.com.cn/cn/DFSStaticFiles/Option/2019/%s/OptionDataExercise.htm'

# 品种映射
# map={'bt':'http://www.czce.com.cn/cn/sspz/bt/H770204index_1.htm#tabs-3','mh':'http://www.czce.com.cn/cn/sspz/mh/H770203index_1.htm#tabs-3',
#      'xm':'http://www.czce.com.cn/cn/sspz/pm/H770202index_1.htm','qm':'http://www.czce.com.cn/cn/sspz/qm/H770201index_1.htm',
#      'zcd':'http://www.czce.com.cn/cn/sspz/zxd/H770207index_1.htm','wcd':'http://www.czce.com.cn/cn/sspz/wxd/H770214index_1.htm',
#      'gd':'http://www.czce.com.cn/cn/sspz/jd/H770213index_1.htm','cp':'http://www.czce.com.cn/cn/sspz/czp/H770211index_1.htm',
#      'cz':'http://www.czce.com.cn/cn/sspz/ycz/H770210index_1.htm','czy':'http://www.czce.com.cn/cn/sspz/czy/H770206index_1.htm',
#      'ms':'http://www.czce.com.cn/cn/sspz/miansha/H770219index_1.htm','pg':'http://www.czce.com.cn/cn/sspz/pg/H770221index_1.htm',
#      'gzhz':'http://www.czce.com.cn/cn/sspz/hzqh/H770222index_1.htm','dlm':'http://www.czce.com.cn/cn/sspz/dlm/H770212index_1.htm',
#      'ejs':'http://www.czce.com.cn/cn/sspz/pta/H770205index_1.htm','jc':'http://www.czce.com.cn/cn/sspz/jc/H770208index_1.htm',
#      'bl':'http://www.czce.com.cn/cn/sspz/bl/H770209index_1.htm','gt':'http://www.czce.com.cn/cn/sspz/gt/H770217index_1.htm',
#      'mg':'http://www.czce.com.cn/cn/sspz/meng/H770220index_1.h
map = ['http://www.czce.com.cn/cn/sspz/bt/H770204index_1.htm#tabs-3',
       'http://www.czce.com.cn/cn/sspz/mh/H770203index_1.htm#tabs-3',
       'http://www.czce.com.cn/cn/sspz/pm/H770202index_1.htm', 'http://www.czce.com.cn/cn/sspz/qm/H770201index_1.htm',
       'http://www.czce.com.cn/cn/sspz/zxd/H770207index_1.htm', 'http://www.czce.com.cn/cn/sspz/wxd/H770214index_1.htm',
       'http://www.czce.com.cn/cn/sspz/jd/H770213index_1.htm', 'http://www.czce.com.cn/cn/sspz/czp/H770211index_1.htm',
       'http://www.czce.com.cn/cn/sspz/ycz/H770210index_1.htm', 'http://www.czce.com.cn/cn/sspz/czy/H770206index_1.htm',
       'http://www.czce.com.cn/cn/sspz/miansha/H770219index_1.htm',
       'http://www.czce.com.cn/cn/sspz/pg/H770221index_1.htm',
       'http://www.czce.com.cn/cn/sspz/hzqh/H770222index_1.htm',
       'http://www.czce.com.cn/cn/sspz/dlm/H770212index_1.htm',
       'http://www.czce.com.cn/cn/sspz/pta/H770205index_1.htm', 'http://www.czce.com.cn/cn/sspz/jc/H770208index_1.htm',
       'http://www.czce.com.cn/cn/sspz/bl/H770209index_1.htm', 'http://www.czce.com.cn/cn/sspz/gt/H770217index_1.htm',
       'http://www.czce.com.cn/cn/sspz/meng/H770220index_1.htm']

# 白糖期货合约
# SUGAR = 'http://www.czce.com.cn/cn/sspz/bt/H770204index_1.htm#tabs-3'
# # 棉花期权合约
# COTTIN = 'http://www.czce.com.cn/cn/sspz/mh/H770203index_1.htm#tabs-3'
# # 小麦期货合约
# WHEAT = 'http://www.czce.com.cn/cn/sspz/pm/H770202index_1.htm'
# # 强麦期货
# JCM = 'http://www.czce.com.cn/cn/sspz/qm/H770201index_1.htm'
# # 早籼稻期货合约
# INDICA = 'http://www.czce.com.cn/cn/sspz/zxd/H770207index_1.htm'
#
# # 晚籼稻期货合约
# ILATE = 'http://www.czce.com.cn/cn/sspz/wxd/H770214index_1.htm'
# # 粳稻期货合约
# JAPONICA = 'http://www.czce.com.cn/cn/sspz/jd/H770213index_1.htm'
# # 菜粕期货合约
# MEAL = 'http://www.czce.com.cn/cn/sspz/czp/H770211index_1.htm'
# # 菜籽期货合约
# RAPESEED = 'http://www.czce.com.cn/cn/sspz/ycz/H770210index_1.htm'
# # 菜籽油期货合约
# OIL = 'http://www.czce.com.cn/cn/sspz/czy/H770206index_1.htm'
# # 棉纱期货合约
# COTTON = 'http://www.czce.com.cn/cn/sspz/miansha/H770219index_1.htm'
# # 苹果期货合约
# APPLE = 'http://www.czce.com.cn/cn/sspz/pg/H770221index_1.htm'
# # 干制红枣（简称“红枣”）
# DRIED = 'http://www.czce.com.cn/cn/sspz/hzqh/H770222index_1.htm'
# # 动力煤期货合约.1
# THERMAL = 'http://www.czce.com.cn/cn/sspz/dlm/H770212index_1.htm'
# # 精对苯二甲酸期货合约.1
# TEREPHTHALIC = 'http://www.czce.com.cn/cn/sspz/pta/H770205index_1.htm'
# # 甲醇期货合约
# METHANO = 'http://www.czce.com.cn/cn/sspz/jc/H770208index_1.htm'
# # 玻璃期货合约.1
# GLASS = 'http://www.czce.com.cn/cn/sspz/bl/H770209index_1.htm'
# # 硅铁期货合约.1
# FERROSILICON = 'http://www.czce.com.cn/cn/sspz/gt/H770217index_1.htm'
# # 锰硅标准合约.1
# MANGANESE = 'http://www.czce.com.cn/cn/sspz/meng/H770220index_1.htm'

# ---------------------------------------------------------------------------------------
# 中金期货
# from 中金 import *
from datetime import datetime

z_tesw = '20190617'


# z_tesw = '20190621'

def z_day_one(td):
    # 日日期规则
    timeArray = time.strptime(td, '%Y%m%d')
    return time.strftime('%Y%m/%d', timeArray)


def z_day_two(td):
    timeArray = time.strptime(td, '%Y%m%d')
    return time.strftime('%Y%m%d', timeArray)


# print(ontherstyletime)
# GOLD_FUTURES_DATE = ontherstyletime
# GOLD_FUTURES_DATE_TWO=ontherstymetime_two


# -----------------
# 周日期规则
def z_week_one(td):
    week = datetime.strptime(td, '%Y%m%d').weekday()
    tesw = int(td) - week
    td = str(tesw)
    timeArray = time.strptime(td, '%Y%m%d')
    return time.strftime('%Y%m/%d', timeArray)


def z_week_two(td):
    week = datetime.strptime(td, '%Y%m%d').weekday()
    tesw = int(td) - week
    td = str(tesw)
    timeArray = time.strptime(td, '%Y%m%d')
    return time.strftime('%Y%m%d', timeArray)


# timeArray = time.strptime(z_tesw, '%Y%m%d')
# # ------------------
# 月日期规则
def month_1(td):
    month_tews = td[:-2]

    timeArray = time.strptime(month_tews, '%Y%m')
    return time.strftime('%Y%m', timeArray)


# month_ontherstymetime_two=time.strftime('%Y%m',timeArray)
# MONTH_GOLD_FUTURES_DATA=month_ontherstyletime
# MONTH_GOLD_FUTURES_DATA_TWO=month_ontherstymetime_two

# print(timeArray)
def p_leader(td):
    timeArray = time.strptime(td, '%Y%m%d')
    return time.strftime('%Y%m/%d', timeArray)


# 日日期规则


# 中金期货日行情数据Daily market data

DAILY_MARKET_DATA = 'http://www.cffex.com.cn/sj/hqsj/rtj/%s/%s_1.csv'

# 周行情数据Weekly market data
WEEKLY_MARKET_DATA = 'http://www.cffex.com.cn/sj/hqsj/ztj/%s/%s_1.csv'
# 月行情数据Monthly market data
MONTHLY_MARKET_DATA = 'http://www.cffex.com.cn/sj/hqsj/ytj/%s/%s_1.csv'

# 成交持仓排名Deal leader
DEAL_LEADER = 'http://www.cffex.com.cn/sj/ccpm/%s/IF_1.csv'

# -----------------------------------------------------------------------------------------------
# 大连期货常量
tesw = '20190613'

timeArray = time.strptime(tesw, '%Y%m%d')
ontherstyletime = time.strftime('%Y%m%d', timeArray)
# print(ontherstyletime)
DALIAN_FUTURES_DATE = ontherstyletime
HEADERS = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    'Cache-Control': 'max-age=0',
    'Connection': 'keep-alive',
    'Cookie': 'WMONID=mekinhiPrUH; Hm_lvt_a50228174de2a93aee654389576b60fb=1562286729,1562546121,1562638262,1562649575; Hm_lpvt_a50228174de2a93aee654389576b60fb=1562649577',
    'Host': 'www.dce.com.cn',
    'If-Modified-Since': 'Thu, 04 Jul 2019 01:52:40 GMT',
    'If-None-Match': "96e8-58cd13ba0ca00",
    'Referer': 'http://www.dce.com.cn/',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36'
}

# 大连日行情表Dalian daily marke
DALIAN_DAILY_MARKE = 'http://www.dce.com.cn/publicweb/quotesdata/dayQuotesCh.html'
#
# DALIAN_DAILY_MARKE_DATA = {
#     'dayQuotes.variety': 'all',
#     'dayQuotes.trade_type': '0',
#     'year': "%s",
#     # 因str不能做加减故转换成int在转换str
#     'month': str(int(DALIAN_FUTURES_DATE[4:6]) - 1),
#     # 'month':'5',
#     'day': DALIAN_FUTURES_DATE[6:8]
# }
# 夜盘行情Night plate prices
NIGTH_PLATE_PRICES = 'http://www.dce.com.cn/publicweb/quotesdata/tiNightQuotes.html'
# NIGTH_PLATE_PRICES_DATA = {
#     # 'tiNightQuotes.variety': 'all',
#     # 'tiNightQuotes.trade_type': '0',
#     'year': DALIAN_FUTURES_DATE[:4],
#     'month': str(int(DALIAN_FUTURES_DATE[4:6]) - 1),
#     'day': DALIAN_FUTURES_DATE[6:8]
# }

# 成交持仓排名Transaction position ranking
TRANSACTION_POSITION_RANKING = 'http://www.dce.com.cn/publicweb/quotesdata/memberDealPosiQuotes.html'
# TRANSACTION_POSITION_RANKING_DATA = {
#     # 'memberDealPosiQuotes.variety': 'all',
#     # 'memberDealPosiQuotes.trade_type': '0',
#     'year': DALIAN_FUTURES_DATE[:4],
#     'month': str(int(DALIAN_FUTURES_DATE[4:6]) - 1),
#     'day': DALIAN_FUTURES_DATE[6:8],
#     # 'contract.contract_id': [],
#     # 'contract.variety_id': 'a',
# }

# 仓单日报Warehouse daily
DALIAN_WAREHOUSE_DAILY = 'http://www.dce.com.cn/publicweb/quotesdata/wbillWeeklyQuotes.html'
# DALIAN_WAREHOUSE_DAILY_DATA = {
#     'wbillWeeklyQuotes.variety': 'all',
#     # 'dayQuotes.trade_type': '0',
#     'year': DALIAN_FUTURES_DATE[:4],
#     'month': str(int(DALIAN_FUTURES_DATE[4:6]) - 1),
#     'day': DALIAN_FUTURES_DATE[6:8],
# }

# 交割配对表Delivery pairing
DALIAN_DELIVERY_PAIRING = 'http://www.dce.com.cn/publicweb/quotesdata/deliveryMatch.html'
# DALIAN_DELIVERY_PAIRING_DATA = {
#     'deliveryMatchQuotes.variety': 'a',
#     'contract.contract_id': 'all',
#     'contract.variety_id': 'a',
#
# }
# 一次性交割卖方仓单查询
SELLER_WAREHOUSE_RECEIPT_INQUIRY = 'http://www.dce.com.cn/publicweb/quotesdata/tcCongregateDeliveryQuotes.html'
# 从几月 From a few months
cong = '201901'
dao = '201906'
# 到几月To a few months
# 交割数据 delivery data
timeArray = time.strptime(cong, '%Y%m')
ontherstylecong = time.strftime('%Y%m', timeArray)
# print(ontherstylecong)
# print(ontherstyletime)
# 从几月
FROM_A_FEW_MOTHS = ontherstylecong
# 交割数据 delivery data
timeArray = time.strptime(dao, '%Y%m')
ontherstyledao = time.strftime('%Y%m', timeArray)
# print(ontherstyledao)
TO_A_FEW_MONTHS = ontherstyledao
# 大连交割数据
DALIANDELIVERY_DATA = 'http://www.dce.com.cn/publicweb/quotesdata/delivery.html'
# 大连阶段成交排名
STAGE_TRANSACTION_RANKING = 'http://www.dce.com.cn/publicweb/quotesdata/memberDealCh.html'

# 合约最值统计
MAXIMUM_COUNT = 'http://www.dce.com.cn/publicweb/quotesdata/contractMonthMax.html'

# 品种月度统计表 期货
VARIETY_MONTHLY_STATISTICAL = 'http://www.dce.com.cn/publicweb/quotesdata/varietyMonthYearStatCh.html'
# 合约停板查询
CONTRACT_SUSPENSION_ENQUIRY = 'http://www.dce.com.cn/publicweb/quotesdata/riseFallEvent.html'
# 期转现结果
TO_SEEING_THE_RESULTS = 'http://www.dce.com.cn/publicweb/quotesdata/ftsDeal.html'

# DALIANDELIVERY_DATA_DATA = {
#     # 从几月
#     'deliveryQuotes.begin_month': FROM_A_FEW_MOTHS,
#     # 到几月
#     'deliveryQuotes.end_month': TO_A_FEW_MONTHS,
#     'deliveryQuotes.variety:': 'all',
#     'month': [],
#     'day': []
# }
# 玉米期货合约
# dalian_mapp={'yumi':'http://www.dce.com.cn/dalianshangpin/sspz/ym/hyygz/486238/index.html','dianfen':'http://www.dce.com.cn/dalianshangpin/sspz/2081746/2081749/2081867/index.html',
#              'dd1':'http://www.dce.com.cn/dalianshangpin/sspz/487124/487128/1391009/index.html','dd2':'http://www.dce.com.cn/dalianshangpin/sspz/487153/487157/6040854/index.html',
#              'dp':'http://www.dce.com.cn/dalianshangpin/sspz/487180/487184/1391326/index.html','yxjyx':'http://www.dce.com.cn/dalianshangpin/sspz/487342/487346/1498988/index.html',
#              'jlxy':'http://www.dce.com.cn/dalianshangpin/sspz/487369/487373/1499103/index.html','jbyx':'http://www.dce.com.cn/dalianshangpin/sspz/487396/487400/1499431/index.html',
#              'jt':'http://www.dce.com.cn/dalianshangpin/sspz/487423/487427/1499525/index.html','jm':'http://www.dce.com.cn/dalianshangpin/sspz/487450/487454/1500228/index.html',
#              'tks':'http://www.dce.com.cn/dalianshangpin/sspz/487477/487481/1500303/index.html','yec':'http://www.dce.com.cn/dalianshangpin/sspz/yec63/6138350/6139005/index.html',}


# dalian_mapp = [
# #     'http://www.dce.com.cn/dalianshangpin/sspz/ym/hyygz/486238/index.html',
# #     'http://www.dce.com.cn/dalianshangpin/sspz/2081746/2081749/2081867/index.html',
# #     'http://www.dce.com.cn/dalianshangpin/sspz/487124/487128/1391009/index.html',
# #     'http://www.dce.com.cn/dalianshangpin/sspz/487153/487157/6040854/index.html',
# #     'http://www.dce.com.cn/dalianshangpin/sspz/487180/487184/1391326/index.html',
# #     'http://www.dce.com.cn/dalianshangpin/sspz/487342/487346/1498988/index.html',
# #     'http://www.dce.com.cn/dalianshangpin/sspz/487369/487373/1499103/index.html',
# #     'http://www.dce.com.cn/dalianshangpin/sspz/487396/487400/1499431/index.html',
# #     'http://www.dce.com.cn/dalianshangpin/sspz/487423/487427/1499525/index.html',
# #     'http://www.dce.com.cn/dalianshangpin/sspz/487450/487454/1500228/index.html',
# #     'http://www.dce.com.cn/dalianshangpin/sspz/487477/487481/1500303/index.html',
# #     'http://www.dce.com.cn/dalianshangpin/sspz/yec63/6138350/6139005/index.html'
# # ]
DAL_MAP = ['http://www.dce.com.cn/dalianshangpin/sspz/ym/hyygz/486238/index.html',
           'http://www.dce.com.cn/dalianshangpin/sspz/2081746/2081749/2081867/index.html',
           'http://www.dce.com.cn/dalianshangpin/sspz/487124/487128/1391009/index.html',
           'http://www.dce.com.cn/dalianshangpin/sspz/487153/487157/6040854/index.html',
           'http://www.dce.com.cn/dalianshangpin/sspz/487180/487184/1391326/index.html',
           'http://www.dce.com.cn/dalianshangpin/sspz/487342/487346/1498988/index.html',
           'http://www.dce.com.cn/dalianshangpin/sspz/487369/487373/1499103/index.html',
           'http://www.dce.com.cn/dalianshangpin/sspz/487396/487400/1499431/index.html',
           'http://www.dce.com.cn/dalianshangpin/sspz/487423/487427/1499525/index.html',
           'http://www.dce.com.cn/dalianshangpin/sspz/487450/487454/1500228/index.html',
           'http://www.dce.com.cn/dalianshangpin/sspz/487477/487481/1500303/index.html',
           'http://www.dce.com.cn/dalianshangpin/sspz/yec63/6138350/6139005/index.html'
           ]
# yumi='http://www.dce.com.cn/dalianshangpin/sspz/ym/hyygz/486238/index.html'
# # 玉米淀粉期货合约
# dianfen='http://www.dce.com.cn/dalianshangpin/sspz/2081746/2081749/2081867/index.html'
# # 黄大豆1号期货合约
# huangda1='http://www.dce.com.cn/dalianshangpin/sspz/487124/487128/1391009/index.html'
# # 黄大豆2号期货合约
# huangda2='http://www.dce.com.cn/dalianshangpin/sspz/487153/487157/6040854/index.html'
# # 豆粕期货合约
# doupa='http://www.dce.com.cn/dalianshangpin/sspz/487180/487184/1391326/index.html'
# # 线型低密度聚乙烯期货合约
# yixi='http://www.dce.com.cn/dalianshangpin/sspz/487342/487346/1498988/index.html'
# # 聚氯乙烯期货合约
# juluyixi='http://www.dce.com.cn/dalianshangpin/sspz/487369/487373/1499103/index.html'
# # 聚丙烯期货合约
# jubing='http://www.dce.com.cn/dalianshangpin/sspz/487396/487400/1499431/index.html'
# # 焦炭期货合约
# jt='http://www.dce.com.cn/dalianshangpin/sspz/487423/487427/1499525/index.html'
# # 焦煤期货合约
# jm='http://www.dce.com.cn/dalianshangpin/sspz/487450/487454/1500228/index.html'
# # 铁矿石期货合约
# tks='http://www.dce.com.cn/dalianshangpin/sspz/487477/487481/1500303/index.html'
# # 乙二醇期货合约
# yec='http://www.dce.com.cn/dalianshangpin/sspz/yec63/6138350/6139005/index.html'
