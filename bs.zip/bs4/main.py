from 上海期货 import *
from 大连期货 import *
from 郑州期货 import *


class Zhengzhou_close:

    # 郑州期货每日行情
    def daily_market(self, td):
        return daily_market(td)

    #       郑州期货结算参数
    def settlement_parameter(self, td):
        return settlement_parameter(td)

    # 郑州期权成交排名
    def deal_the_ranking(self, td):
        return deal_the_ranking(td)

    # 郑州期权持仓排名
    def position_ranking(self, td):
        return position_ranking(td)

    # 郑州期权套保持仓
    def hedge_position(self, td):
        return hedge_position(td)

    # 仓单日报
    def house_daily(self, td):
        return house_daily(td)

    # 期权阶段成交排名表1
    def futures_stage_transactions(self, go, to):
        return futures_stage_transactions(go, to)

    # 期权阶段成交排名表2

    def option_phase_trading_table(self, go, to):
        return option_phase_trading_table(go, to)

    # 期转现统计
    def forward_transfer_statistics(self):
        return forward_transfer_statistics()

    # 月度交割查询
    def monthly_settlement_inquiry(self, td):
        return monthly_settlement_inquiry(td)

    # 月度行权查询

    def monthly_exercise_query(self, td):
        return monthly_exercise_query(td)

    # 郑州期权合约
    def sugar_futures_contract(self):
        return sugar_futures_contract()

    def own(self, td):
        return daily_market(td), settlement_parameter(td), deal_the_ranking(td), position_ranking(td), hedge_position(
            td), house_daily(td), forward_transfer_statistics(), monthly_settlement_inquiry(td), monthly_exercise_query(
            td), sugar_futures_contract()


a = Zhengzhou_close()


class Dalian_close:
    # 大连日行情表
    def quotation(self, td):
        return quotation(td)

    # 夜盘行情
    def night_plate_prices(self, td):
        return night_plate_prices(td)

    # 大连日程交持仓排名
    def position_ranking(self, td):
        return position_ranking(td)

    # 仓单日报
    def warehouse_daily(self, td):
        return warehouse_daily(td)

    # 大连交割配对表
    def delivery_pairing(self):
        return delivery_pairing()

    #  大连交割数据
    def delivery_data(self, form_go, to_go):
        return delivery_data(form_go, to_go)

    # 一次性交割卖方仓单查询
    def seller_warehouse_receipt_inquiry(self, td):
        return seller_warehouse_receipt_inquiry(td)

    # 阶段成交排名
    def stage_transaction_ranking(self, form_go, to_go):
        return stage_transaction_ranking(form_go, to_go)

    # 阶段成交排名期权
    def stage_transaction_ranking_two(self, form_go, to_go):
        return stage_transaction_ranking_two(form_go, to_go)

    # 品种月度统计表 期货
    def variety_monthly_statistical(self, td):
        return variety_monthly_statistical(td)

    # 品种月度统计表 期权
    def variety_monthly_statistical_two(self, td):
        return variety_monthly_statistical_two(td)

    # 合约停板查询
    def contract_suspension_enquiry(self, form_go, to_go):
        return contract_suspension_enquiry(form_go, to_go)

    # 期转现结果
    def to_seeing_the_results(self, form_go, to_go):
        return to_seeing_the_results(form_go, to_go)

    # 大连期货合约
    def futures_contract(self):
        return futures_contract()

    # 合约最值统计 期货
    '''
     合约最值统计 期货
        日期已做处理 填入字符串 YYYYMMDD
        xy控制类型
        ty控制期权期货 ty=0 期货 ty=1 期权
        xy=0 成交量统计
        xy=1 成交额统计
        xy=2 持仓量统计
        xy=3 价格统计
    '''

    def maximum_count_volume(self, xy, form_go, to_go):
        return maximum_count_volume(xy, form_go, to_go)

    def dalian_own(self, td):
        return quotation(td), night_plate_prices(td), position_ranking(td), warehouse_daily(
            td), delivery_pairing(), seller_warehouse_receipt_inquiry(td), variety_monthly_statistical(
            td), variety_monthly_statistical_two(td), futures_contract()


b = Dalian_close()


class Shanghai_close:
    # 每日行情
    def week_market(self, sj):
        return week_market(sj)

    # 交易参数/
    def trading_parameters(self, sj):
        return trading_parameters(sj)

    # # 上海期货交易所会员成交及持仓排名表
    def list_of_member_transactions_and_positions(self, sj):
        return list_of_member_transactions_and_positions(sj)

    # # 上海期货交易所期货合约行情
    def futures_contracts(self, sj):
        return futures_contracts(sj)

    # # 上海期货交易所指定交割仓库期货仓单日报
    def designated_delivery_warehouse(self, sj):
        return futures_contracts(sj)

    # 上海期货交易所指定交割仓库库存周报/
    def inventory_weekly(self, sj):
        return inventory_weekly(sj)

    # 上海期货交易所各品种日间均价
    def average_price(self, sj):
        return average_price(sj)

    # 各品种合约加权平均价1
    def average_price2(self, sj):
        return average_price2(sj)

    # # 各品种合约加权平均价2
    def average_price3(self, sj):
        return average_price3(sj)

    # # 上海期货交易所每周行情
    def inventory_weekly1(self, sj):
        return inventory_weekly1(sj)

    # 上海期货交易所上市品种月度参考价
    def monthly_reference(self, sj):
        return monthly_reference(sj)

    # # 上海期货交易所每月行情
    def monthly_updates(self, sj):
        return monthly_updates(sj)

    # 合约参数一览
    def contract_parameters(self, sj):
        return contract_parameters(sj)

    # 合约参数一览 衍生品
    def futures_derivatives(self, sj):
        return futures_derivatives(sj)

    # 获取合约参数一览每日行情
    def parameters_daily(self, sj):
        return parameters_daily(sj)

    # 获取合约参数一览 每日行情 衍生品
    def quote_derivatives(self, sj):
        return quote_derivatives(sj)

    # 获取合约参数一览 每周行情 衍生品
    def weekly_quotes_2(self, sj):
        return weekly_quotes_2(sj)

    # 上海期货合约
    def shang_contract(self):
        return shang_contract()

    # 衍生品
    def derivative(self):
        return derivative()

    def shanghai_own(self, sj):
        return week_market(sj), trading_parameters(sj), list_of_member_transactions_and_positions(
            sj), futures_contracts(sj), futures_contracts(sj), inventory_weekly(sj), average_price(sj), average_price2(
            sj), average_price3(sj), inventory_weekly1(sj), monthly_reference(sj), monthly_updates(
            sj), contract_parameters(sj), futures_derivatives(sj), parameters_daily(sj), quote_derivatives(
            sj), weekly_quotes_2(sj), shang_contract(), derivative()


c = Shanghai_close()
# 每日行情
# print(a.daily_market('20190708'))
# # 郑州期货结算参数
# print(a.settlement_parameter('20190708'))
# #郑州期权成交排名
# print(a.deal_the_ranking('20190617'))
# #郑州期权持仓排名
# print(a.position_ranking('20190617'))
# #郑州期权套保持仓
# print(a.hedge_position('sugar_futures_contract()'))
# #仓单日报
# print(a.house_daily('20190617'))
# #期权阶段成交排名表1
# print(a.futures_stage_transactions('20190607','20190705'))
# # 期权阶段成交排名表2
# print(a.option_phase_trading_table('20190607','20190705'))
# # 期转现统计
# print(a.forward_transfer_statistics())
# # 月度交割查询
# print(a.monthly_settlement_inquiry('20190607'))
# # 月度行权查询
# print(a.monthly_exercise_query('20190607'))
# #郑州期权合约
# print(a.sugar_futures_contract())
# 所有的
# print(a.own('20190617'))


# 大连交易所

# print(b.quotation('20190617'))
# 夜盘行情
# print(b.night_plate_prices('20190617'))
# 大连日程交持仓排名
# print(b.position_ranking('20190617'))
# 仓单日报
# print(b.warehouse_daily('20190617'))
# 大连交割配对表
# print(b.delivery_pairing())
#  大连交割数据
# print(b.delivery_data('20190501','20190607'))
# 一次性交割卖方仓单查询
# print(b.seller_warehouse_receipt_inquiry('20190617'))
# # 阶段成交排名
# print(b.stage_transaction_ranking('20190501','20190607'))
# # 阶段成交排名期权
# print(b.stage_transaction_ranking_two('20190501','20190607'))
# # 品种月度统计表 期货
# print(b.variety_monthly_statistical('20190617'))
#
# # 品种月度统计表 期权
# print(b.variety_monthly_statistical_two('20190617'))
# # 合约停板查询
# print(b.contract_suspension_enquiry('20190501','20190607'))
# # 期转现结果
# print(b.to_seeing_the_results('20190501','20190607'))
# # 大连期货合约
# print(b.futures_contract())
# '''
#      合约最值统计 期货
#         日期已做处理 填入字符串 YYYYMMDD
#         xy控制类型
#         ty控制期权期货 ty=0 期货 ty=1 期权
#         xy=0 成交量统计
#         xy=1 成交额统计
#         xy=2 持仓量统计
#         xy=3 价格统计
#     '''
# print(b.maximum_count_volume(1,'20190501','20190607'))
# 返回所有只需要传入一个参数的函数
print(b.dalian_own('20190617'))
#
# #上海交易所
# #每日行情
# print(c.week_market('20190617'))
# # 交易参数/
# print(c.trading_parameters('20190617'))
# # 上海期货交易所会员成交及持仓排名表
# print(c.list_of_member_transactions_and_positions('20190617'))
# # 上海期货交易所期货合约行情
# print(c.futures_contracts('20190617'))
# # 上海期货交易所指定交割仓库期货仓单日报
# print(c.designated_delivery_warehouse('20190617'))
# # 上海期货交易所指定交割仓库库存周报
# print(c.inventory_weekly)
# # 上海期货交易所各品种日间均价
# print(c.average_price('20190617'))
# # 各品种合约加权平均价1
# print(c.average_price2('20190617'))
# # 各品种合约加权平均价2
# print(c.average_price3('20190617'))
# # 上海期货交易所每周行情
# print(c.inventory_weekly1('20190617'))
# # 上海期货交易所上市品种月度参考价
# print(c.monthly_reference('20190617'))
# # 上海期货交易所每月行情
# print(c.monthly_updates('20190617'))
# # 合约参数一览
# print(c.contract_parameters('20190617'))
# # 合约参数一览 衍生品
# print(c.futures_derivatives('20190617'))
# # 获取合约参数一览每日行情
# print(c.parameters_daily('20190617'))
# # 获取合约参数一览 每日行情 衍生品
# print(c.quote_derivatives('20190617'))
# # 获取合约参数一览 每周行情 衍生品
#
# print(c.weekly_quotes_2('20190617'))
# # 上海期货合约
# print(c.shang_contract())
# # 衍生品
# print(c.derivative())
# 返回所有只需要填写一个参数的函数
# print(c.shanghai_own('20190617'))
