from xpinyin import Pinyin
import pandas as pd
import os
import psycopg2
from sqlalchemy import create_engine
db_conn='postgresql://' +'future_rw'+':'+'lA0cl5p8weik6ltO'+'@'+'119.3.212.60'+':'+'5432'+'/' +\
             'future'
engine=create_engine(db_conn)

# conn_1=psycopg2.connect(database="future", user="future_rw", password="lA0cl5p8weik6ltO",
#                                host="119.3.212.60",
#                                port="5432")
# cur1=conn_1.cursor()
# print(cur1)
import xlwt
import xlrd
import xlsxwriter
path='2016'
for i in os.walk(path):
    for j in i[2]:
        df=pd.read_csv('2016\\%s'%(j),encoding ='GB2312')
        # print(df)

        df=df.iloc[:,2:]

        data=df.columns

        l={}

        for i in data:

            p=Pinyin()
            test=p.get_initials(i,'')
            test=test.lower()
            l[i]=test


        df=df.rename(columns=l)
        df.to_sql('odl_fu_dc_day_%s' % (path), engine, schema="odl", index=False, if_exists="replace", chunksize=1000)
        print(df)
        print(j)





