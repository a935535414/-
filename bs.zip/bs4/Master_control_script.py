from 上海期货 import *
# from 中金期货 import  *
from 大连期货 import *
from 郑州期货 import *


class Main_entrance:
    '''
    # dc大连 sc上海 zc郑州
    '''

    def the_daily_market(self, td, jys=None):
        '''week_market 上海期货每日行情
            quotation  大连商品交易总入口
            daily_market 郑州期货每日行情
        :param td:
        :param jys:
        :return:
        '''

        if jys == 'sc':
            return week_market(td)
        elif jys == 'dc':
            return quotation(td)
        elif jys == 'zc':
            return daily_market(td)
        else:


            df = week_market(td)
            if df is not None:
                df['jys'] = 'sc'
            df = daily_market(td)
            if not df:
                df['jys'] = 'dc'
            #
            df = quotation(td)

            if not df:
                df['jys'] = 'zc'
            return df,df,df



    def aggregate_transaction_data(self, td, jys):
        '''
        aggregate_transaction_data 总的交易数据
        trading_parameters 上海期货交易数据

        settlement_parameter 郑州期货结算参数
        :param td:
        :param jys:
        :return:
        '''
        if jys == 'sc':
            return trading_parameters(td)
        elif jys == 'dc':
            return None

        elif jys == 'zc':
            return settlement_parameter(td)
        else:
            df=trading_parameters(td)
            if df is not None:
                df['jys']='sc'
            df=settlement_parameter(td)
            if not df:
                df['jys']='zc'

            return df,df

    def total_position_table(self, td, jys):
        '''
        总持仓排名表 total_position_table
         list_of_member_transactions_and_positions 上海期货交易所会员成交及持仓排名表
         position_ranking 大连成交持仓排名
         hedge_position 郑州期权套保持仓
        :param td:
        :param jys:
        :return:
        '''
        if jys == 'sc':
            # 上海
            return list_of_member_transactions_and_positions(td)
        elif jys == 'dc':
            # 大连
            return position_ranking(td)
            # return delivery_data(td)
        elif jys == 'zc':
            # 郑州
            return hedge_position(td)
        else:
            df=list_of_member_transactions_and_positions(td)
            if df is not None:
                df['jys']='sc'

            df=position_ranking(td)

            if df is not None:
                df['jys']='dc'
            return df
    def total_futures_contracts(self, td, jys):
        '''
        总期货合约行情
        futures_contracts  上海期货交易所期货合约行情
        warehouse_daily 大连仓单日报
        house_daily 郑州期权仓单日报
        :param td:
        :param jys:
        :return:
        '''
        if jys == 'sc':
            # 上海
            return futures_contracts(td)
        elif jys == 'dc':
            # 大连
            return warehouse_daily(td)
            # return delivery_data(td)
        elif jys == 'zc':
            # 郑州
            return house_daily(td)
        else:
            df =futures_contracts(td)
            if df is not None:
                df['jys']='sc'
            df =warehouse_daily(td)
            if not df:
                df['jys']='dc'
            df =house_daily(td)
            if not df:
                df['jys']='dc'
            return df,df,df
    def daily_report_of_futures_warehouse(self, td, jys):
        '''
        总指定交割仓库期货仓单日报
        designated_delivery_warehouse 上海期货交易所指定交割仓库期货仓单日报

        :param td:
        :param jys:
        :return:
        '''
        if jys == 'sc':
            # 上海
            return designated_delivery_warehouse(td)
        elif jys == 'dc':
            # 大连
            return None
            # return delivery_data(td)
        elif jys == 'zc':
            # 郑州
            return None
        else:
            df=designated_delivery_warehouse(td)
            if df is not None:
                df['jys']='sc'
            return df

    def report_of_total_designated(self, td, jys):
        '''
        总指定交割仓库库存周报
        inventory_weekly 上海期货交易所指定交割仓库库存周报

        :param td:
        :param jys:
        :return:
        '''
        if jys == 'sc':
            # 上海
            return inventory_weekly(td)
        elif jys == 'dc':
            # 大连
            return None
            # return delivery_data(td)
        elif jys == 'zc':
            # 郑州
            return None
        else:
            df=inventory_weekly(td)
            if df is not None:
                df['jys']='sc'
            return df
    def price_of_each_variety(self, td, jys):
        '''
        各品种日间均价
        average_price 上海期货交易所各品种日间均价

        :param td:
        :param jys:
        :return:
        '''
        if jys == 'sc':
            # 上海
            return average_price(td)
        elif jys == 'dc':
            # 大连
            return None
            # return delivery_data(td)
        elif jys == 'zc':
            # 郑州
            return None
        else:
            df=average_price(td)
            if df is not None:
                df['jys']='sc'
            return df


    def average_price_of_each_variety1(self, td, jys):
        '''
        各品种合约加权平均价
        average_price2 各品种合约加权平均价1

        :param td:
        :param jys:
        :return:
        '''
        if jys == 'sc':
            # 上海
            return average_price2(td)
        elif jys == 'dc':
            # 大连
            return None
            # return delivery_data(td)
        elif jys == 'zc':
            # 郑州
            return None
        else:
            df=average_price2(td)
            if df is not None:
                df['jys']='sc'
            return df

    def average_price_of_each_variety2(self, td, jys):
        '''
        各品种合约加权平均价2
        average_price3 各品种合约加权平均价2

        :param td:
        :param jys:
        :return:
        '''
        if jys == 'sc':
            # 上海
            return average_price3(td)
        elif jys == 'dc':
            # 大连
            return None
            # return delivery_data(td)
        elif jys == 'zc':
            # 郑州
            return None
        else:
            df=average_price3(td)
            if df is not None:
                df['jys']='sc'
            return df


    def total_weekly_quotation(self, td, jys):
        '''
        总每周行情
        inventory_weekly 上海期货交易所每周行情
        :param td:
        :param jys:
        :return:
        '''
        if jys == 'sc':
            # 上海
            return inventory_weekly(td)
        elif jys == 'dc':
            # 大连
            return None
            # return delivery_data(td)
        elif jys == 'zc':
            # 郑州
            return None
        else:
            df=inventory_weekly(td)
            if df is not None:
                df['jys']='sc'
            return df

    def varieties_monthly_reference_price(self, td, jys):
        '''
        总上市品种月度参考价
        monthly_reference 上海期货交易所上市品种月度参考价
        :param td:
        :param jys:
        :return:
        '''
        if jys == 'sc':
            # 上海
            return monthly_reference(td)
        elif jys == 'dc':
            # 大连
            return None
            # return delivery_data(td)
        elif jys == 'zc':
            # 郑州
            return None
        else:
            df=monthly_reference(td)
            if df is not None:
                df['jys']='sc'
            return df

    def total_monthly_quotation(self, td, jys):
        '''
        总每月行情
         monthly_updates 上海期货交易所每月行情
        :param td:
        :param jys:
        :return:
        '''
        if jys == 'sc':
            # 上海
            return monthly_updates(td)
        elif jys == 'dc':
            # 大连
            return None
            # return delivery_data(td)
        elif jys == 'zc':
            # 郑州
            return None
        else:
            df=monthly_updates(td)
            if df is not None:
                df['jys']='sc'
            return df

    def total_night_quotation(self, td, jys):
        '''
        总夜盘行情
         night_plate_prices 大连夜盘行情
        :param td:
        :param jys:
        :return:
        '''
        if jys == 'sc':
            # 上海
            return None
        elif jys == 'dc':
            # 大连
            return night_plate_prices(td)
            # return delivery_data(td)
        elif jys == 'zc':
            # 郑州
            return None
        else:
            df=night_plate_prices(td)
            if df  is not None:
                df['jys']='dc'
            return df
    def total_closing_pairs(self, jys):
        '''
        总交割配对表
        不需要传入日期，return所有数据
        delivery_pairing 大连交割配对表
        :param td:
        :param jys:
        :return:
        '''
        if jys == 'sc':
            # 上海
            return None
        elif jys == 'dc':
            # 大连
            return delivery_pairing()
            # return delivery_data(td)
        elif jys == 'zc':
            # 郑州
            return None
        else:
            df=delivery_pairing()
            if not df:
                df['jys']='dc'
            return df




    #总的种类
    def total_species(self,jys,kind):
        if jys == 'sc':
            # 上海
            return None
        elif jys == 'dc':
            # 大连
            return delivery_pairing()
            # return delivery_data(td)
        elif jys == 'zc':
            # 郑州
            return sugar_futures_contract(kind)
        else:
            df = delivery_pairing()
            if not df:
                df['jys'] = 'dc'
            return df
    #总期货
    def total_futures(self,td,jys):
        if jys == 'sc':
            # 上海
            return contract_parameters(td)

        elif jys == 'dc':
            # 大连
            pass
            # return delivery_data(td)
        elif jys == 'zc':
            # 郑州
           pass
        else:
            df = contract_parameters(td)
            if not df:
                df['jys'] = 'sc'
            return df
    # 总衍生品
    def total_derivatives(self,td,jys):
        if jys == 'sc':
            # 上海
            return futures_derivatives(td)

        elif jys == 'dc':
            # 大连
            pass
            # return delivery_data(td)
        elif jys == 'zc':
            # 郑州
            pass
        else:
            df = futures_derivatives(td)
            if not df:
                df['jys'] = 'sc'
            return df

    def total_delivery_data(self, form_go, to_go, jys):
        '''
        总交割数据
        delivery_data 大连交割数据
        form_go 从几月 to_go 到几月
        字符串已做处理直接输入YYYYMMDD
        :param form_go:
        :param to_go:
        :param jys:
        :return:
        '''
        if jys == 'sc':
            # 上海
            return None
        elif jys == 'dc':
            # 大连
            return delivery_data(form_go, to_go)
        elif jys == 'zc':
            return None
            # 郑州

        else:
            df=delivery_data(form_go,to_go)
            if not df:
                df['jys']='dc'
            return df



a = Main_entrance()

# print(a
'''
需要填入的参数td('YYYMMDD')第二个jys(dc大连 sc上海 zc郑州(不填全部打印))


总每日行情 the_daily_market
总的交易数据 aggregate_transaction_data
总持仓排名表 total_position_table
总期货合约行情 total_futures_contracts
总指定交割仓库期货仓单日报 daily_report_of_futures_warehouse
总指定交割仓库库存周报 report_of_total_designated
各品种日间均价 price_of_each_variety
各品种合约加权平均价 average_price_of_each_variety1
各品种合约加权平均价2 average_price_of_each_variety2
总每周行情 total_weekly_quotation
总上市品种月度参考价 varieties_monthly_reference_price
总每月行情 total_monthly_quotation
总夜盘行情  total_night_quotation
# 不需要传入数据
总交割配对表 total_closing_pairs
总期货交易月历 monthly_transaction_calendar
总期权成交排名 option_trading_ranking
总交割数据 total_delivery_data
'''

# print(a.the_daily_market('20190617'))
# print(a.aggregate_transaction_data('20190617', 'c'))
# print(a.total_position_table('20190614', 'z'))
# print(a.total_futures_contracts('20190617', 'z'))
# print(a.daily_report_of_futures_warehouse('20190617', 'c'))
# print(a.report_of_total_designated('20190617', 'z'))
# print(a.price_of_each_variety('20190617', 'z'))
# print(a.average_price_of_each_variety1('20190617', 'c'))
# print(a.average_price_of_each_variety2('20190617', 'c'))
# print(a.total_weekly_quotation('20190617', 'z'))
# print(a.varieties_monthly_reference_price('20190617', 'c'))
# print(a.total_monthly_quotation('20190617', 'c'))
# # 不需要传入日期
# print(a.total_closing_pairs('z'))
# # print(a.monthly_transaction_calendar('20190614','c'))
# # print(a.option_trading_ranking('20190617', 'z'))
# print(a.total_delivery_data('20190101', '20190601','z'))
print(a.total_species('zc','pg'))
#
