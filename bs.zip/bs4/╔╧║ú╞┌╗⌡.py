from bs4 import BeautifulSoup
import re
import pandas as pd
import requests
from urllib import error
from code_normally import *
import urllib.request
from urllib import request
from urllib import parse
# import json
import time
import base64

import json


# 每日行情
def week_market(sj):
    '''
获取上海期货每日行情
日期已做处理 填入字符串 YYYY-MM-DD

-------
DataFrme    合约代码 instrumentid
            周开盘价openprice
            最高价closeprice
            最低价lowestprice
            周末收盘价closeprice
            周末结算价settlementprice
            跌涨pricechg
            成交量volume
            持仓量 openinterest
            成交额,turnover
            行权量,

    '''
    try:
        sj = day1(sj)
        url = SHANGHAI_FUTURES_url % (sj)

        # http://www.shfe.com.cn/data/instrument/ContractDailyTradeArgument20190619.dat

        # 获取json数据
        soup = requests.get(url, heards)
        # str形式的数据
        data = soup.text
        # 把str转换成dict
        data = eval(data)

        test_dict_df = pd.DataFrame(data[WEEK_MARKET_DATA])
        return test_dict_df

    except:
        return None


# week_market('20190617')
# 交易参数/
def trading_parameters(sj):
    '''
    获取上海期货交易数据
    日期已做处理 填入字符串 YYYY-MM-DD

    # DataFrme
            合约代码，instrumentid
            投机买保证金率，hdege_longmarginratio
            投机卖保证金率，hdege_shortmarginratio
            套保买保证金率，spec_longmarginratio
            套保卖保证金率，spec_shortmatginratio
            跌停板幅度，lower_value
            涨停板幅度，upper_value


    '''

    try:
        sj = day1(sj)
        soup = requests.get(RRADE_PARAMETER_URL % (sj), heards)
        data = soup.text
        # 把str转换成dict
        data = eval(data)

        test_dict_df = pd.DataFrame(data[RRADE_PARAMETER_URL_DATA])
        return test_dict_df
    except:
        return None


# trading_parameters('20190617')


# #
# #
# # # # 上海期货交易所会员成交及持仓排名表
def list_of_member_transactions_and_positions(sj):
    '''
    获取上海期货会员成交及持仓排名表
    日期已做处理 填入字符串 YYYY-MM-DD
    DataFrme
            期货公司会员简称participantabbr1
            成交量cj1
            比上交易日期递减,cj1_chg
            期货公司会员简称,participantabbr2
            持买单量,cj2
            比上交易日增减,cj2_chg
            名次,rank
            期货公司会员简称,participantabbr3
            持卖单量,cj3
            比上交易日期增/变化,cj3_chg


    :param sj:
    :return:
    '''

    try:
        sj = day1(sj)
        soup = requests.get(MEMBER_TRANSACTIONS_AND_POSITIONS % (sj), heards)
        data = soup.text
        # print(data)
        # 把str转换成dict
        data = eval(data)

        test_dict_df = pd.DataFrame(data['o_cursor'])
        return test_dict_df
    except:
        return None


# list_of_member_transactions_and_positions('20190617')


#
#
# # 上海期货交易所期货合约行情
def futures_contracts(sj):
    '''
    获取上海期货合约行情
    日期已做处理 填入字符串 YYYY-MM-DD
    DataFrme
            交割月份 ，deliverymonth
            前结算presettlementprice
            今开盘 ，openprice
            最高价 ，highestprice
            最低价，lowestprice
            结算参考价，settlementprice
            跌涨1 ，zd1_chg
            跌涨2，zd2_chg
            成交手，volume
            持仓手 ,openinterest
            变化 ,openinterestchg
            小计,volume
            持仓手openinterest
            持仓手,openinterestchg



    :param sj:
    :return:
    '''

    try:
        sj = day1(sj)
        soup = requests.get(CONTRACT_QUOTATION % (sj), heards)
        data = soup.text
        # print(data)
        # 把str转换成dict
        data = eval(data)
        # print(data)

        test_dict_df = pd.DataFrame(data['o_curinstrument'])
        return test_dict_df
    except:
        return None


# futures_contracts('20160617')


#
#
# # 上海期货交易所指定交割仓库期货仓单日报
def designated_delivery_warehouse(sj):
    '''
  获取上海期货指定交割仓库期货仓单日报
  日期已做处理 填入字符串 YYYY-MM-DD
  DataFrme
        品种,varname
        地区,regname
        仓库,whabbrname
        期货,wrtwghts
        递增,wrtchange
        地区期货合计,wrtchange
        地区递减合计,wrtwghts
        合计期货,wrtwghts
        合计递减,wrtchange
        保税商品总计 ,wrtwghts
        保税商品总计,wrtwghts
        总计期货 ,wrtwghts
        总计增减wrtchange


    :param sj:
    :return:
    '''

    try:
        sj = day1(sj)
        soup = requests.get(DESIGNATED_DELIVERY_WAREHOUSE % (sj), heards)

        data = soup.text
        # print(data)
        # 把str转换成dict
        data = eval(data)

        test_dict_df = pd.DataFrame(data['o_cursor'])
        return test_dict_df
    except:
        return None


# designated_delivery_warehouse('20190617')


#
#
# # 20190614
# # 上海期货交易所指定交割仓库库存周报/
def inventory_weekly(sj):
    '''
    获取上海期货指定交割仓库期货仓单周报
    日期已做处理 填入字符串 YYYY-MM-DD
  DataFrme
            品种， varname
            地区，REGNAME' regname
            仓库，whabbraname
            上周库存小计，prespotwghts
            上周库存期货，prewrtwghts
            本周库存小计，spotwghts
            本周库存期待，wrtwghts
            库存增减小计，spotchange
            库存增减期货， wrtchange
            可用库容量上周， prewhstocks
            可用库容量本周，whstocks
            可用库容量增减， whstockchange
            上周库存小计合计， prespotwghts
            上周库存期货合计，prewrtwghts
            本周库存小计合计， spotwghts
            本周库存期待合计， wrtwghts
            库存增减小计合计， spotchange
            库存增减期货合计， wrtchange
            可用库容量上周合计，prewhstocks
            可用库容量本周合计，whstocks
            可用库容量增减合计，whstockchange
            总计期货,wrtwghts
            总计增减,wrtch
    :param sj:
    :return:
    '''

    try:
        sj = day1(sj)
        soup = requests.get(WAREHOUSE_INVENTORY_WEEKLY % (sj), heards)
        data = soup.text
        # print(data)
        # 把str转换成dict
        data = eval(data)
        # print(data)

        test_dict_df = pd.DataFrame(data['o_cursor'])
        return test_dict_df
    except:
        return None


# inventory_weekly('20190617')


#
#
# # 上海期货交易所各品种日间均价

def average_price(sj):
    '''
      获取上海期货各品种日间均价
    日期已做处理 填入字符串 YYYY-MM-DD
    DataFrme
            合约名称,instrumentid
            时间,time
            加权平均价,refsettlementprice
            较前一日涨跌, updown
    :param sj:
    :return:
    '''

    try:
        sj = day1(sj)
        soup = requests.get(WEIGHTED_AVERAGE_PRICE % (sj), heards)
        data = soup.text
        # print(data)
        # 把str转换成dict
        data = eval(data)
        # print(data)

        test_dict_df = pd.DataFrame(data['o_currefprice'])
        return test_dict_df
    except:
        return None


# average_price('20190617')


#
#
# # 各品种合约加权平均价1
def average_price2(sj):
    '''
     获取上海期货当前合约加权平均价表1
    日期已做处理 填入字符串 YYYY-MM-DD
    DataFrme
            合约名称,instrumentid
            时间,time
            加权平均价,refsettlementprice
            较前一日涨跌, updown
    :param sj:
    :return:
    '''

    try:
        sj = day1(sj)
        soup = requests.get(AVERAGE_PRICE_OF_EACH_VARIETY_ONE % (sj), heards)
        data = soup.text
        # print(data)
        # 把str转换成dict
        data = eval(data)
        # print(data)

        test_dict_df = pd.DataFrame(data['o_currefprice'])
        return test_dict_df
    except:
        return None


# average_price2('20190617')


#
#
# # 各品种合约加权平均价2
def average_price3(sj):
    '''
     获取上海期货当前合约加权平均价表2
    日期已做处理 填入字符串 YYYY-MM-DD
    DataFrme
             合约名称,instrumentid
             时间，time
             加权平均价，refsettlementprice
             较前一日涨跌，updown
             类型，productid
    :param sj:
    :return:
    '''

    try:
        sj = day1(sj)
        soup = requests.get(AVERAGE_PRICE_OF_EACH_VARIETY_WTO % (sj), heards)
        data = soup.text
        # print(data)
        # 把str转换成dict
        data = eval(data)
        # print(data)

        test_dict_df = pd.DataFrame(data['o_currefprice'])
        return test_dict_df
    except:
        return None


# average_price3('20190617')


#
#
# # 上海期货交易所每周行情
def inventory_weekly1(sj):
    '''
    获取上海期货每周行情
    日期已做处理 填入字符串 YYYY-MM-DD
    DataFrme
            商品名称, product
            交割月份,instrumentid
            周开盘价,openprice
            最高价,highestprice
            最低价,lowestprice
            周末收盘价,closeprice
            跌涨,pricechg
            持仓变化,openinterestchg
            持仓量,openinterest
           持仓变化,openinterestchg
            周末结算价,settlementprice
            成交量,volume
            成交金额,turnover
    :param sj:
    :return:
    '''

    try:
        sj = day1(sj)
        soup = requests.get(WEEK_MARKET % (sj), heards)
        data = soup.text
        # print(data)
        # 把str转换成dict
        data = eval(data)
        # print(data)

        test_dict_df = pd.DataFrame(data['o_cursor'])
        return test_dict_df
    except:
        return None


#
#
# # 上海期货交易所上市品种月度参考价
def monthly_reference(sj):
    '''
    上海期货交易所上市品种月度参考价
    日期已做处理 填入字符串 YYYY-MM-DD
    DataFrme
            品种,description
            开盘价,openprice
            最高价,high
            最低价, low
            收盘价,closeprice
            期末结算价, settle
            月度结算参考价,setav
           月度结算参考价涨跌,setchange
    :param sj:
    :return:
    '''

    try:
        sj = day1(sj)
        soup = requests.get(MONTHLY_REFERENCE_PRICE % (sj), heards)
        data = soup.text
        # print(data)
        # 把str转换成dict
        data = eval(data)
        # print(data)

        test_dict_df = pd.DataFrame(data['o_cursor'])
        return test_dict_df
    except:
        return None


# monthly_reference('20190617')


#
# # 上海期货交易所每月行情
def monthly_updates(sj):
    '''
     获取上海期货每月行情
     日期已做处理 填入字符串 YYYY-MM-DD
     DataFrme
            商品名称, product
            割月份,instrumentid
            月开盘价,openprice
            最高价,highestprice
            最低价,lowestprice
            月收盘价,closeprice
            涨跌,pricechg
            持仓量,openinterest
            持仓变化,openinterestchg
            月末结算价,settlementprice
            成交量,volume
            成交金额, turnover
    :param sj:
    :return:
    '''

    try:
        sj = day1(sj)
        soup = requests.get(MONTHLY_REFERENCE_PRICE % (sj), heards)
        data = soup.text
        # print(data)
        # 把str转换成dict
        data = eval(data)
        # print(data)

        test_dict_df = pd.DataFrame(data['o_cursor'])
        return test_dict_df
    except:
        return None


# b=monthly_updates('20190617')
# print(b)

# 合约参数一览
def contract_parameters(sj):
    '''
     获取合约参数一览 期货
     日期已做处理 填入字符串 YYYY-MM-DD
     DataFrme
            挂牌基准价 basisprice
            最后交割日 enddeeelivdte
            合约代码 instrumentid
            上市日 opendate
            开始交割日 startdelivdate
            交易日期 tradingday
            开始交割日 startdelivdate

    :param sj:
    :return:
    '''

    try:
        sj = day1(sj)
        soup = requests.get(CONTRACT_PARAMETERS % (sj), heards)
        data = soup.text
        # print(data)
        # 把str转换成dict
        data = eval(data)
        # print(data)

        test_dict_df = pd.DataFrame(data['ContractBaseInfo'])
        return test_dict_df
    except:
        return None
    # 合约参数一览 衍生品


def futures_derivatives(sj):
    '''
     获取合约参数一览 衍生品
     日期已做处理 填入字符串 YYYY-MM-DD
     DataFrme
           品种 commodityname
           最后交易日 exp_ipedate
           合约代码 instrumentid
           开始交易日 opendate
           最小变动价位 pricetick
           交易单位 tradeunit
           交易日期 tradingday


    :param sj:
    :return:
    '''

    try:
        sj = day1(sj)
        soup = requests.get(FUTURES_DERIVATIVES % (sj), heards)
        data = soup.text
        # print(data)
        # 把str转换成dict
        data = eval(data)
        # print(data)

        test_dict_df = pd.DataFrame(data['OptionContractBaseInfo'])
        return test_dict_df
    except:
        return None


def parameters_daily(sj):
    '''
     # 获取合约参数一览 每日行情
     日期已做处理 填入字符串 YYYY-MM-DD
     DataFrme
           交割月份 deliverymonth
           前结算 presettlementprice
           今开盘 openprice
           最高价 highestprice
           最低价 lowestprice
           收盘价 closeprice
           结算参考价 settlementprice
           涨跌1 zd1_chg
           涨跌2 zd2_chg
           成交手 volume
           持仓手 openinterest
           变化 openinterestchg


    :param sj:
    :return:
    '''

    try:
        sj = day1(sj)
        soup = requests.get(PARAMETERS_DAILY % (sj), heards)
        data = soup.text
        # print(data)
        # 把str转换成dict
        data = eval(data)
        # print(data)

        test_dict_df = pd.DataFrame(data['o_curinstrument'])
        return test_dict_df
    except:
        return None


def quote_derivatives(sj):
    '''
     获取合约参数一览 每日行情 衍生品
     日期已做处理 填入字符串 YYYY-MM-DD
     DataFrme
          合约代码 instrumentid
          开盘价 openprice
          最高价 highestprice
          最低价 lowestprice
          收盘价 closeprice
          前结算价 presettlementprice
          结算价 settlementprice
          涨跌1 zd1_chg
          涨跌2 zd2_chg
          成交量 volume
          持仓量 openinterest
          持仓变化 openinterestchg
          成交额 turnover
          德尔塔 delta
          行权量 execvolume



    :param sj:
    :return:
    '''

    try:
        sj = day1(sj)
        soup = requests.get(QUOTE_DERIVATIVES % (sj), heards)
        data = soup.text
        # print(data)
        # 把str转换成dict
        data = eval(data)
        # print(data)

        test_dict_df = pd.DataFrame(data['o_curinstrument'])
        return test_dict_df
    except:
        return None


def weekly_quotes_2(sj):
    '''
     获取合约参数一览 每周行情 衍生品
     日期已做处理 填入字符串 YYYY-MM-DD
     DataFrme
          合约代码 instrumentid
          周开盘价 openprice
          最高价 highestprice
          最低价 lowestprice
          周末收盘价 closeprice
          周末结算价 settlementprice
          涨跌 pricechg
          成交量 volume
          持仓量 openinterest
          持仓变化 openinterestchg
          成交额 turnover
          行权量 execvolume



    :param sj:
    :return:
    '''

    try:

        sj = day1(sj)
        soup = requests.get(WEEKLY_QUOTES % (sj), heards)
        data = soup.text
        # print(data)
        # 把str转换成dict
        data = eval(data)
        # print(data)

        test_dict_df = pd.DataFrame(data['o_cursor'])
        return test_dict_df
    except:
        return None


# b=weekly_quotes_2('20190704')

import numpy as np


# 上海期货合约
def shang_contract():
    l = []
    try:

        urls = shang_mapp
        data = tian_data
        df1 = pd.DataFrame(data, index=[1])
        # print(df)

        data2 = shi_data
        df2 = pd.DataFrame(data2, index=[1])
        for url in urls:

            r = requests.get(url, heards)
            # print(r)
            r.encoding = 'utf-8'

            df = pd.read_html(r.text, parse_dates=True, header=0)

            df = df[0]

            x = np.array(df).tolist()

            bb = {}

            for i in x:
                #
                bb[i[0]] = i[1]

            df = pd.DataFrame(bb, index=[0])
            l.append(df)
            l.append(df1)
            l.append(df2)

        return pd.concat(l)

    except:
        return None


oii = shang_contract()


# #衍生品
def derivative():
    l = []
    # df={}
    try:
        for url in MAPSS:
            r = requests.get(url, heards)
            r.encoding = 'utf-8'
            df = pd.read_html(r.text, parse_dates=True, header=0)
            df = df[0]
            x = np.array(df).tolist()
            # print (x)
            # print(x)
            bb = {}
            # b1={}
            # l=[]
            for i in x:
                # print (x[0],x[1])
                # print (x[0][i],x[1][i])
                bb[i[0]] = i[1]
            # print(bb)
            df = pd.DataFrame(bb, index=[0])
            # df=pd.DataFrame(b,index=[0])
            l.append(df)

        # print (l)
        #
        #
        # dfd = pd.concat(l)
        # dfd.to_excel('2122.xlsx')
        return pd.concat(l, sort=True)
    except:
        return None


# derivative()

# monthly_updates('20190617')
#
# def of_settlement_parameters():
#     # for i in range(54,2):
#     url=f'http://www.shfe.com.cn/bourseService/businessdata/parametertable/index.html'
#     r=requests.get(url,heards)
#     soup=BeautifulSoup(r.text,'lxml')
#     html=soup.select(' div.p4.lawbox > ul  li  a::attr(herf)')
#     print(html)
#
# of_settlement_parameters()
