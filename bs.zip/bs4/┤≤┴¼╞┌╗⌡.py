import numpy as np
# 日行情表
from code_normally import *

from bs4 import BeautifulSoup
import requests
import pandas as pd
import csv


def quotation(td):
    '''
   大连日行情表
        日期已做处理 填入字符串 YYYYMMDD


#   DataFrme
            商品名称
            交割月份
            开盘价
            最高价
            最低价
            收盘价
            前结算价
            结算价
            涨跌
            涨跌1
            成交量
            持仓量
            持仓变化
            成交额
    :param tr:
    :return:
    '''

    try:
        headers = HEADERS

        r = requests.post(NIGTH_PLATE_PRICES, data={
            'tiNightQuotes.variety': 'all',
            'tiNightQuotes.trade_type': '0',
            'year': td[:4],
            'month': str(int(td[4:6]) - 1),
            'day': td[6:8],
        })

        a = pd.read_html(r.text, parse_dates=True, header=0)
        return a
    except:
        return None


# zpp=quotation('20190617')
# print(zpp)


#
# # # 夜盘行情
def night_plate_prices(td):
    '''
    大连夜盘行情
        日期已做处理 填入字符串 YYYYMMDD
     DataFrme
            品种
            交割月份
            开盘价
            最高价
            最低价
            最新价
            涨跌
            买价/卖价
            前结算价
            成交量
            持仓量
            持仓变化
            成交额
    :param td:
    :return:
    '''

    try:
        headers = HEADERS

        r = requests.post(NIGTH_PLATE_PRICES, data={
            'tiNightQuotes.variety': 'all',
            'tiNightQuotes.trade_type': '0',
            'year': td[:4],
            'month': str(int(td[4:6]) - 1),
            'day': td[6:8],
        })

        soup = BeautifulSoup(r.text, 'lxml')

        body = soup.select('table')
        df_list = []
        for i in body:
            # print(i)

            for _ in body:
                df_list.append(pd.concat(pd.read_html(i.prettify())))

        a = (df_list)
        return a
    except:
        return None


# night_plate_prices('20190621')
# print(a)
#
#
# #
# #
# # # 成交持仓排名
# #
# # #
def position_ranking(td):
    '''
    大连日程交持仓排名
        日期已做处理 填入字符串 YYYYMMDD
#   DataFrme
        名次
        会员简称
        成交量
        增减
        名次

    :param td:
    :return:
    '''
    try:
        headers = HEADERS

        r = requests.post(TRANSACTION_POSITION_RANKING, data={
            'memberDealPosiQuotes.variety': 'all',
            'memberDealPosiQuotes.trade_type': '0',
            'year': td[:4],
            'month': str(int(td[4:6]) - 1),
            'day': td[6:8],
            'contract.contract_id': [],
            'contract.variety_id': 'a',
        })

        a = pd.read_html(r.text, parse_dates=True, header=0)

        return a
    except:
        return None


# position_ranking('20190621')
# print(b)


# #
# #
# # # 仓单日报
# #
# #
def warehouse_daily(td):
    '''
    大连仓单日报
        日期已做处理 填入字符串 YYYYMMDD
#   DataFrme
        品种
        仓库/分库
        昨日仓单量
        今日仓单量
        增减
    :param td:
    :return:
    '''

    try:
        # headers = HEADERS

        r = requests.post(DALIAN_WAREHOUSE_DAILY, data={
            'wbillWeeklyQuotes.variety': 'all',
            # 'dayQuotes.trade_type': '0',
            'year': td[:4],
            'month': str(int(td[4:6]) - 1),
            'day': td[6:8],
        })

        a = pd.read_html(r.text, parse_dates=True, header=0)
        return a
    except:
        return None


# warehouse_daily('')
# print(c)


#
#
# # #
# #
# # #
def delivery_pairing():
    '''
    大连交割配对表
        日期已做处理 填入字符串 YYYYMMDD
        DataFrme
            合约号
            配对日期
            买会员号
            配对手数
            卖会员号
            交割结算价
    :return:
    '''
    try:
        headers = HEADERS

        r = requests.post(DALIAN_DELIVERY_PAIRING, data={
            'deliveryMatchQuotes.variety': 'a',
            'contract.contract_id': 'all',
            'contract.variety_id': 'a',

        })

        a = pd.read_html(r.text, parse_dates=True, header=0)

        return a
    except:
        return None


#
# delivery_pairing()
# print(d)


#
# 交割数据
def delivery_data(form_go, to_go):
    '''
        大连交割数据
        日期已做处理 填入字符串 YYYYMMDD
        DataFrme
            品种
            合约
            交割日期
            交割量
            交割金额
    :param form_go:
    :param to_go:
    :return:
    '''
    try:
        headers = HEADERS

        r = requests.post(DALIANDELIVERY_DATA, data={
            # 从几月
            'deliveryQuotes.begin_month': form_go,
            # 到几月
            'deliveryQuotes.end_month': to_go,
            'deliveryQuotes.variety:': 'all',
            'month': [],
            'day': []
        })

        a = pd.read_html(r.text, parse_dates=True, header=0)
        return a
    except:
        return None


# 一次性交割卖方仓单查询
def seller_warehouse_receipt_inquiry(td):
    try:
        url = SELLER_WAREHOUSE_RECEIPT_INQUIRY
        r = requests.post(url, data={
            'tcCongregateDeliveryQuotes.variety_id': 'all',

            'tcCongregateDeliveryQuotes.contract_month': td[:-2],
        })
        a=pd.read_html(r.text,parse_dates=True)
        return a
    except:
        return None



# y=seller_warehouse_receipt_inquiry('20190615')
# print(y)
# 阶段成交排名
def stage_transaction_ranking(form_go, to_go):
    '''
        大连阶段成交排名期货
        日期已做处理 填入字符串 YYYYMMDD

    :param form_go:
    :param to_go:
    :return:
    '''
    try:
        headers = HEADERS

        r = requests.post(STAGE_TRANSACTION_RANKING, data={
            # 从几月
            'memberDealQuotes.trade_type': '0',
            'memberDealQuotes.begin_month': form_go[:-2],
            # 到几月
            'memberDealQuotes.end_month': to_go[:-2],
            'memberDealQuotes.variety': 'all',
            'month': [],
            'day': []
        })

        a = pd.read_html(r.text, parse_dates=True, header=0)
        return a
    except:
        return None
# sa=stage_transaction_ranking('20190510','20190610')

# 阶段成交排名期权
def stage_transaction_ranking_two(form_go, to_go):
    '''
        大连阶段成交排名期权
        日期已做处理 填入字符串 YYYYMMDD

    :param form_go:
    :param to_go:
    :return:
    '''
    try:
        headers = HEADERS

        r = requests.post(STAGE_TRANSACTION_RANKING, data={
            # 从几月
            'memberDealQuotes.trade_type': '1',
            'memberDealQuotes.begin_month': form_go[:-2],
            # 到几月
            'memberDealQuotes.end_month': to_go[:-2],
            'memberDealQuotes.variety': 'all',
            'month': [],
            'day': []
        })

        a = pd.read_html(r.text, parse_dates=True, header=0)
        return a
    except:
        return None
# stage_transaction_ranking_two('20190505','20190701')
# 合约最值统计 期货
def maximum_count_volume(xy,form_go, to_go):
    '''
        合约最值统计 期货
        日期已做处理 填入字符串 YYYYMMDD
        xy控制类型
        ty控制期权期货 ty=0 期货 ty=1 期权
        xy=0 成交量统计
        xy=1 成交额统计
        xy=2 持仓量统计
        xy=3 价格统计


    :param form_go:
    :param to_go:
    :return:
    '''
    try:
        headers = HEADERS

        r = requests.post(MAXIMUM_COUNT, data={
            # 从几月
            'contractMonthMaxQuotes.trade_type': '0',
            'statContent': xy,
            'memberDealQuotes.begin_month': form_go[:-2],
            # 到几月
            'memberDealQuotes.end_month': to_go[:-2],
            'memberDealQuotes.variety': 'all',
            'month': [],
            'day': []
        })

        a = pd.read_html(r.text, parse_dates=True, header=0)
        return a
    except:
        return None
# maximum_count_volume('3','20190505','20190701')
# 合约最值统计 期权
# def maximum_count_volume(xy,form_go, to_go):
#     '''
#         合约最值统计 期权
#         日期已做处理 填入字符串 YYYYMMDD
#         xy控制类型
#         ty控制期权期货 ty=0 期货 ty=1 期权
#         xy=0 成交量统计
#         xy=1 成交额统计
#         xy=2 持仓量统计
#         xy=3 价格统计
#
#
#     :param form_go:
#     :param to_go:
#     :return:
#     '''
#     try:
#         headers = HEADERS
#
#         r = requests.post(MAXIMUM_COUNT, data={
#             # 从几月
#             'contractMonthMaxQuotes.trade_type': '1',
#             'statContent': xy,
#             'memberDealQuotes.begin_month': form_go[:-2],
#             # 到几月
#             'memberDealQuotes.end_month': to_go[:-2],
#             'memberDealQuotes.variety': 'all',
#             'month': [],
#             'day': []
#         }, headers=headers)
#
#         a = pd.read_html(r.text, parse_dates=True, header=0)
#         return a
#     except:
#         return None
# maximum_count_volume('3','20190505','20190701')
# 品种月度统计表 期货
def variety_monthly_statistical ( td):
    '''
        # 品种月度统计表 期货
        日期已做处理 填入字符串 YYYYMMDD



    :param form_go:
    :param to_go:
    :return:
    '''
    try:
        headers = HEADERS

        r = requests.post(VARIETY_MONTHLY_STATISTICAL, data={
            # 从几月
            'varietyMonthYearStatQuotes.trade_type': '0',
            'statContent': [],
            'varietyMonthYearStatQuotes.begin_month': td[:-2],
            'memberDealQuotes.variety': 'all',
            'month': [],
            'day': []
        })

        a = pd.read_html(r.text, parse_dates=True, header=0)
        return a
    except:
        return None
# variety_monthly_statistical('20190505')
# 品种月度统计表 期权
def variety_monthly_statistical_two(td):
    '''
        # 品种月度统计表 期权
        日期已做处理 填入字符串 YYYYMMDD



    :param form_go:
    :param to_go:
    :return:
    '''
    try:
        headers = HEADERS

        r = requests.post(VARIETY_MONTHLY_STATISTICAL, data={
            # 从几月
            'varietyMonthYearStatQuotes.trade_type': '1',
            'statContent': [],
            'varietyMonthYearStatQuotes.begin_month': td[:-2],
            'memberDealQuotes.variety': 'all',
            'month': [],
            'day': []
        })

        a = pd.read_html(r.text, parse_dates=True, header=0)
        return a
    except:
        return None
# variety_monthly_statistical_two('20190505')

# 合约停板查询
def contract_suspension_enquiry(form_go, to_go):
    '''
        大连 合约停板查询
        日期已做处理 填入字符串 YYYYMMDD

    :param form_go:
    :param to_go:
    :return:
    '''
    try:
        headers = HEADERS

        r = requests.post(CONTRACT_SUSPENSION_ENQUIRY, data={
            # 从几月,
            'riseFallEventQuotes.begin_month': form_go[:-2],
            # 到几月
            'riseFallEventQuotes.end_month': to_go[:-2],
            'memberDealQuotes.variety': 'all',

        })

        a = pd.read_html(r.text, parse_dates=True, header=0)
        return a
    except:
        return None
# contract_suspension_enquiry('20190505','20190701')
# 期转现结果
def to_seeing_the_results(form_go, to_go):
    try:
        headers = HEADERS

        r = requests.post(TO_SEEING_THE_RESULTS, data={
            # 从几月,
            'ftsDealQuotes.begin_month': form_go[:-2],
            # 到几月
            'ftsDealQuotes.end_month': to_go[:-2],
            'ftsDealQuotes.variety':'all',

        })

        a = pd.read_html(r.text, parse_dates=True, header=0)
        return a
    except:
        return None

# to_seeing_the_results('20190415','20190701')
# print(pp)

# 大连期货合约
def futures_contract():
    # urls ='http://www.dce.com.cn/dalianshangpin/sspz/ym/hyygz/486238/index.html','http://www.dce.com.cn/dalianshangpin/sspz/2081746/2081749/2081867/index.html','http://www.dce.com.cn/dalianshangpin/sspz/487124/487128/1391009/index.html'


    l = []
    # df={}

    for url in DAL_MAP:
        # if not type(url) == None
        r = requests.get(url, HEADERS)
        r.encoding = 'utf-8'
        df = pd.read_html(r.text, parse_dates=True, header=0)
        # print(df)
        df = df[0]
        # print(df)
        x = np.array(df).tolist()
        # print (x)
        # print(x)
        bb = {}
        # b1={}
        # l = []
        for i in x:
            # print(i)
        # print (x[0],x[1])
        # print (x[0][i],x[1][i])
            bb[i[0]] = i[1]
    # print(bb)
        df = pd.DataFrame(bb, index=[0])
    # # # df=pd.DataFrame(b,index=[0])
        l.append(df)
    # # print(l)
    # return pd.concat(1)

    # print (l)

    return pd.concat(l,sort=True)

# bu=futures_contract()
# print(bu)






# # #
#
# #  第一个数据从几月 第二个数据到几月
# e=delivery_data('20190501', '20190606')
# print(e)
