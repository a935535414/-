#抓取月度报告

# def monthly_market_report_PDF():
#     import requests
#     from bs4 import BeautifulSoup
#     import pandas as pd
#     heards = {
#         'Accept': 'text / html, application / xhtml + xml, application / xml;q = 0.9, image / webp, image / apng, * / *;q = 0.8, application / signed - exchange;v = b3',
#         'Accept - Encoding': 'gzip, deflateAccept - Language: zh - CN, zh;q = 0.9, en;q = 0.8',
#         'Cache - Control': 'max - age = 0',
#         'Cookie': 'UM_distinctid=16b6934d2da52a-0580f28a0f55ac-e323069-144000-16b6934d2db660; TS014ada8c=0169c5aa321c389b96eb5bfb2fa43b9f9d4fd4c6ccae4f8dd2896fcf6c3748ee99e332b51b; CNZZDATA1264458526=1965444749-1560832974-null%7C1562220643',
#         'Host': 'www.czce.com.cn',
#         'f - Modified - Since': 'Wed, 03 Jul 2019 16:02: 51GMT',
#         'If - None - Match': 'W / "1421f-58cc8fe4780c0"',
#         'Proxy - Connection': 'keep - alive',
#         'Referer': 'http: // www.czce.com.cn / cn / jysj / ydjyhz / H770315index_2.htm',
#         'Upgrade - Insecure - Requests': 1,
#         'User - Agent': 'Mozilla / 5.0(Windows NT 10.0;Win64;x64) AppleWebKit / 537.36(KHTML, likeGecko) Chrome / 73.0.3683.103 Safari / 537.36',
#
#     }
#     pp = 0
#     for i in range(1,8):
#         url='http://www.czce.com.cn/cn/jysj/ydscbg/H770318index_%s.htm'%(i)
#
#         r=requests.get(url,heards)
#
#         # print(r)
#         soup=BeautifulSoup(r.text,'lxml')
#         a=soup.select(' table > tbody > tr:nth-child(1) > td > li > a')
#         # print(a)
#         for n in a:
#             print(n.text)
#             dd='http://www.czce.com.cn' +n['href']
#             pp+=1
#             r=requests.get(dd)
#             print(r.content)
#             with open ('月度市场报告\阅读市场报告%s.pdf'%(pp),'wb') as f:
#                 # f.write(n.text)
#                f.write(r.content)
#                print(r.content)
#
#
# monthly_market_report_PDF()

a='20190515'
b=a[:-2]
print(b)
