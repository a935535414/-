import time
import re
from urllib import request
from urllib import error
import requests
from code_normally import *
import pandas as pd


# 中金期货日统计
def daily_market(td):
    '''
    中金期货日统计
    日期已做处理 填入字符串 YYYYMMDD
    DataFrme
            合约代码
            今开盘
            最高价
            最低价
            成交量
            成交金额
            持仓量
            今收盘
            今结算
            涨跌1
            涨跌2
            隐含波动率（%）
            Delta

    :param td:
    :return:
    '''
    # try:
    td1 = z_day_one(td)
    td2 = z_day_two(td)

    url = DAILY_MARKET_DATA % (td1, td2)

    r=requests.get(url)
    # r.raise_for_status()
    # if r.raise_for_status() ==None:
    #     return None
    # else:

    #
    a = pd.read_csv(url, encoding='gb18030')

    if len(list(a.columns)) <=int(2):

        return None
        # return a.re
    else:
        return a
        #     return None

    # except  :
    #     return None


b = daily_market('20190817')
print(b)

# 周行情数据
def weekly_market(td):
#     '''
#      中国金融期货周行情数据
#     日期已做处理 填入字符串 YYYYMMDD
#     #
#     # -------
# #   DataFrme
#         合约代码
#             周开盘价
#             周最高价
#             周最低价
#             周收盘价
#             涨跌
#             持仓量
#             持仓变化
#             周末结算价
#             成交量
#             成交金额
#     :param td:
#     :return:
#     '''
    try:
        td1 = z_week_one(td)
        td2 = z_week_two(td)
        url = WEEKLY_MARKET_DATA % (td1, td2)

        a = pd.read_csv(url, encoding='gb18030')
        if len(list(a.columns)) <= int(2):

            return None
            # return a.re
        else:
            return a
    except:
        return None


weekly_market('20190717')


# # # #月行情数据
def monthly_market(td):
    '''
     中国金融期货月行情数据
    日期已做处理 填入字符串 YYYYMMDD
    #
    # -------
#   DataFrme
            合约代码
            月开盘价
            月最高价
            月最低价
            月收盘价
            涨跌
            持仓量
            持仓变化
            月末结算价
            成交量
            成交金额

    :param td:
    :return:
    '''
    try:
        td1 = month_1(td)
        td2 = month_1(td)
        url = MONTHLY_MARKET_DATA % (td1, td2)

        a = pd.read_csv(url, encoding='gb18030')

        if len(list(a.columns)) <= int(2):

            return None
            # return a.re
        else:
            return a
    except:
        return None


# monthly_market('20190617')


def deal_leader(td):
    '''
    # 获取中国金融期货成交持仓排名
# 日期已做处理 填入字符串 YYYYMMDD
#
# -------
# DataFrme
            成交量排名
                名次
                会员简称
                成交量
                比上次交易日增减
            持买单量排名
                名次
                会员简称
                持买单量
                比上交易日子增减
            持卖单量排名
                名次
                会员简称
                持卖单量
                比上交易日增减

    :param td:
    :return:
    '''
    try:
        td2 = p_leader(td)
        url = DEAL_LEADER % (td2)

        a = pd.read_csv(url, encoding='gb18030', delimiter="\t")
        if len(list(a.columns)) <= int(2):

            return None
            # return a.re
        else:
            return a
    except:
        return None

    # print(a)


deal_leader('20190605')
