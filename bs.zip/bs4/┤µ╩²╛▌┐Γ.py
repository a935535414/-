import xlrd
import xlwt
from datetime import date, datetime
import pandas as pd


def read_excel():
    workbook = xlrd.open_workbook(r'xlss/2.xls')
    # print(workbook.sheet_names())
    sheet2_name = workbook.sheet_names()[0]
    # print(sheet2_name)
    sheet2 = workbook.sheet_by_index(0)
    # print(sheet2)
    sheet2 = workbook.sheet_by_name('月统计数据汇总')
    row = sheet2.nrows
    # print(row)
    p = 0
    g = 0
    l = []
    for i in range(row):

        rowdata = sheet2.row_values(i)
        # rowdata=[i for i in rowdata[:-1] if i !='']
        rowdata = rowdata[::-1]
        new_Data = []
        for i in rowdata:
            if i == '':
                rowdata.remove(i)


            else:
                new_Data = rowdata[::-1]

                break

        l.append(new_Data)

        #
        if len(new_Data) == g:
            p += 1

        else:
            p = 0

            if len(l) > 5:
                # print(l)
                df = pd.DataFrame(l)
                print(df)
            l = []
        #
        g = len(rowdata)


read_excel()
